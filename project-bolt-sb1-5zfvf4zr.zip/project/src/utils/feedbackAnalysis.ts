import { MedicalCase } from '../lib/supabase';
import { ARNOLD_PETERSON_CASE_ID, ARNOLD_PETERSON_REFERENCE } from './arnoldPetersonReference';
import { PETER_BROOKS_CASE_ID, PETER_BROOKS_REFERENCE } from './peterBrooksReference';

export interface SegmentFeedback {
  text: string;
  feedbackItems: Array<{
    type: 'filler' | 'good' | 'missing' | 'warning';
    message: string;
  }>;
}

export interface SOAPFeedback {
  score: number;
  maxScore: number;
  feedback: string[];
  passed: boolean;
}

export interface FeedbackResult {
  soapSections: {
    frame: SOAPFeedback;
    subjective: SOAPFeedback;
    objective: SOAPFeedback;
    assessment: SOAPFeedback;
    plan: SOAPFeedback;
  };
  metrics: {
    wordCount: number;
    estimatedMinutes: number;
    overallGrade: number;
    fillerWordCount: number;
    fillerWords: Array<{ word: string; count: number }>;
    wordsPerMinute: number;
    excessFillerWords: string[];
  };
  annotatedTranscript: string;
  stepByStepScores: {
    frame: StepScore;
    context: StepScore;
    story: StepScore;
    pertinentFindings: StepScore;
    background: StepScore;
    familyHistory: StepScore;
    objectiveData: StepScore;
    assessment: StepScore;
    plan: StepScore;
  };
  inaccuracies: {
    frame: string[];
    subjective: string[];
    objective: string[];
    assessment: string[];
    plan: string[];
  };
  aiEnhancement?: {
    sectionEnhancements: {
      frame?: string;
      subjective?: string;
      objective?: string;
      assessment?: string;
      plan?: string;
    };
  };
  factCheck?: {
    accuracyIssues: Array<{
      category: 'demographics' | 'history' | 'vitals' | 'labs' | 'assessment' | 'plan';
      issue: string;
      severity: 'critical' | 'moderate' | 'minor';
    }>;
    accuracyScore: number;
    overallAccuracy: string;
  };
}

interface StepScore {
  score: number;
  maxScore: number;
  feedback: string[];
  passed: boolean;
  inaccuracies?: string[];
}

const FILLER_WORDS = [
  // Common Single-Word Fillers
  'uh', 'um', 'er', 'ah', 'like', 'so', 'well', 'okay', 'right', 'yeah', 'basically',
  'literally', 'actually', 'really', 'just', 'kinda', 'sorta', 'maybe', 'perhaps',
  'honestly', 'seriously', 'obviously', 'apparently', 'anyway', 'whatever', 'stuff',
  'things', 'alright', 'umm', 'uhh', 'uhhh', 'ahh',

  // Sentence Starters
  'you know', 'you see', 'i mean', 'i guess', 'i think', 'i suppose', 'i feel like',
  'it seems like', 'to be honest', 'to tell you the truth', 'in my opinion', 'the thing is',
  'what happens is', 'as i was saying', 'the point is', 'the fact is', 'as you know',
  'as i said before', 'as i mentioned', 'so basically', 'so yeah',

  // Pausing / Hesitation Fillers
  'let me see', "let's see", "let's see here", 'hmm', 'uhh okay', 'hang on', 'just a second',
  'one sec', 'give me a moment', 'right so', 'okay so', 'alright then', 'now then',
  'you know what i mean', 'you get me',

  // Transition Fillers
  'and then', 'so then', 'like i said', 'as i said', 'anyways', 'moving on', 'after that',
  'then what happened', 'in other words', 'at the end of the day', 'in a sense', 'sort of like',
  'kind of like',

  // Agreement / Confirmation Fillers
  'uh-huh', 'mm-hmm', 'exactly', 'totally', 'for sure', 'i see', 'got it', 'makes sense',

  // Uncertain or Hedging Fillers
  'possibly', 'probably', 'sort of', 'kind of', 'a little bit', 'somewhat', 'more or less',
  'i believe', "i'm not sure", 'it might be', 'it could be',

  // Softening / Politeness Fillers
  'if that\'s okay', 'if you don\'t mind', 'i just wanted to', 'i was just wondering',
  "it's kind of like",

  // Medical or Academic Speech Fillers
  'to be fair', "if i'm being honest", 'so, in this case', 'so, what happened was',
  'basically, the patient', 'actually, the thing is', 'like, for example', 'you could say',
  'and stuff like that', 'and things like that', 'that kind of thing', 'yeah, so',
  'well, essentially', 'so, um', 'i guess you could say',

  // Conversational Closers
  'and that\'s about it', 'you know what i mean', "that's pretty much it", "i guess that's it",
  'something like that', 'and so on', 'et cetera', 'and whatnot', 'and all that',

  // Redundant or Empty Modifiers
  'completely', 'entirely', 'absolutely', 'definitely', 'pretty much', 'a bit', 'a little', 'slightly'
];

function detectFillerWords(transcript: string): { count: number; breakdown: Array<{ word: string; count: number }>; sentencesWithExcessFillers: string[] } {
  const transcriptLower = transcript.toLowerCase();
  const breakdown: Map<string, number> = new Map();
  let totalCount = 0;

  FILLER_WORDS.forEach(filler => {
    const regex = new RegExp(`\\b${filler}\\b`, 'gi');
    const matches = transcriptLower.match(regex);
    if (matches) {
      const count = matches.length;
      breakdown.set(filler, count);
      totalCount += count;
    }
  });

  const breakdownArray = Array.from(breakdown.entries())
    .map(([word, count]) => ({ word, count }))
    .sort((a, b) => b.count - a.count);

  // Detect sentences with more than 2 filler words
  const sentences = transcript.match(/[^.!?]+[.!?]+/g) || [];
  const sentencesWithExcessFillers: string[] = [];

  sentences.forEach(sentence => {
    const sentenceLower = sentence.toLowerCase();
    let fillerCount = 0;
    const fillersFound: string[] = [];

    FILLER_WORDS.forEach(filler => {
      const regex = new RegExp(`\\b${filler}\\b`, 'gi');
      const matches = sentenceLower.match(regex);
      if (matches) {
        fillerCount += matches.length;
        fillersFound.push(...matches.map(m => m.toLowerCase()));
      }
    });

    if (fillerCount > 2) {
      sentencesWithExcessFillers.push(...fillersFound.filter((f, i, arr) => arr.indexOf(f) === i));
    }
  });

  // Get unique fillers from sentences with excess
  const uniqueExcessFillers = [...new Set(sentencesWithExcessFillers)];

  return { count: totalCount, breakdown: breakdownArray, sentencesWithExcessFillers: uniqueExcessFillers };
}

function countWords(text: string): number {
  return text.trim().split(/\s+/).length;
}

function countSentences(text: string): number {
  return text.split(/[.!?]+/).filter(s => s.trim().length > 0).length;
}

function calculateOverallGrade(stepScores: {
  frame: StepScore;
  context: StepScore;
  story: StepScore;
  pertinentFindings: StepScore;
  background: StepScore;
  familyHistory: StepScore;
  objectiveData: StepScore;
  assessment: StepScore;
  plan: StepScore;
}): number {
  const totalScore = Object.values(stepScores).reduce((sum, step) => sum + step.score, 0);
  const totalMaxScore = Object.values(stepScores).reduce((sum, step) => sum + step.maxScore, 0);
  return totalMaxScore > 0 ? Math.round((totalScore / totalMaxScore) * 100) : 0;
}

function evaluateFrame(transcript: string, medicalCase: MedicalCase, wordsPerMinute?: number): StepScore {
  const feedback: string[] = [];
  const inaccuracies: string[] = [];

  // Professional Greeting (Tip only - not scored)
  // Acceptable: "Hi Dr. Smith", "Hello Dr. Lee", "Good morning, Preceptor", "Hi Preceptor", etc.
  const professionalGreetingPatterns = [
    /^(good morning|good afternoon|good evening|hello|hi|greetings|good day)/i,
    /^(morning|afternoon|evening)\s+(everyone|all|team|colleagues|staff|residents|classmates|dr\.|doctor|preceptor)/i,
    /\b(good morning|good afternoon|good evening|hello|hi)\s+(dr\.|doctor|preceptor|sir|ma'am|team|everyone|all|colleagues|staff|residents|classmates)/i,
    /(hi|hello|good morning|good afternoon|good evening)\s+(preceptor)/i,
  ];

  const firstPart = transcript.slice(0, 200);
  const hasProf = professionalGreetingPatterns.some(pattern => pattern.test(firstPart));

  if (hasProf) {
    feedback.push("✔ Good job on including a professional greeting");
  } else {
    feedback.push("Tip: Consider including a professional greeting (situation dependent)");
  }

  // Chief Complaint Format Part A
  // Extract first 1-3 sentences
  const sentences = transcript.match(/[^.!?]+[.!?]+/g) || [];
  const firstSentences = sentences.slice(0, 3).join(' ');

  // Check if this is Arnold Peterson's or Peter Brooks' case and use reference data
  const isArnoldPeterson = medicalCase.id === ARNOLD_PETERSON_CASE_ID;
  const isPeterBrooks = medicalCase.id === PETER_BROOKS_CASE_ID;

  // Get expected values from medical case or reference data
  const expectedPatientName = isArnoldPeterson ? ARNOLD_PETERSON_REFERENCE.frame.patientName :
                              isPeterBrooks ? PETER_BROOKS_REFERENCE.frame.patientName :
                              medicalCase.patient_name;
  const expectedAge = isArnoldPeterson ? ARNOLD_PETERSON_REFERENCE.frame.age :
                      isPeterBrooks ? PETER_BROOKS_REFERENCE.frame.age :
                      medicalCase.patient_age;
  const expectedSex = isArnoldPeterson ? ARNOLD_PETERSON_REFERENCE.frame.sex :
                      isPeterBrooks ? PETER_BROOKS_REFERENCE.frame.sex :
                      medicalCase.patient_sex?.toLowerCase();
  const expectedComplaint = isArnoldPeterson ? ARNOLD_PETERSON_REFERENCE.frame.chiefComplaint :
                            isPeterBrooks ? PETER_BROOKS_REFERENCE.frame.chiefComplaint :
                            medicalCase.chief_complaint?.toLowerCase();

  // Check for chief complaint patterns (format check) - expanded to include all variations
  const chiefComplaintPatterns = [
    // General/Neutral Openings
    /\b(i have a case of|i'd like to present a case of|today,?\s*i'?ll be presenting a case involving?|i'?ll be discussing a patient who presented with)\b/i,
    /\b(this is a case about|i'?m presenting a patient with|the case i'?m presenting today is about|i'd like to share a case involving?)\b/i,
    /\b(i'?ll be talking about a patient who came in with|this case involves a patient presenting with)\b/i,

    // Formal Academic Openings
    /\b(i would like to present the case of|allow me to present the case of|i will now present a case that highlights?)\b/i,
    /\b(the following case concerns|i will be reviewing a clinical case that demonstrates?|here is a case illustrating)\b/i,
    /\b(i'?ll begin by presenting a case seen in the|this presentation outlines the assessment and management of)\b/i,
    /\b(i will discuss the case of a patient admitted for|this case pertains to a patient presenting with)\b/i,

    // Concise/Clinical Style
    /^\s*\d{1,3}[\s-]*(year[\s-]*old|yo|y\/o)\s+(male|female|man|woman)\s+(presents?|presenting|seen|admitted|referred|evaluated)\s+(with|for|after|because)/i,
    /\b(presents? with|presenting with|seen for|admitted for|referred for|evaluated for|presenting to the (ed|emergency|clinic))\b/i,

    // Teaching/Discussion-Based Openings
    /\b(i'd like to discuss a case that demonstrates?|this case highlights?|this patient'?s presentation raises)\b/i,
    /\b(this case emphasizes|i'?ll be sharing a case that exemplifies|this case provides insight into)\b/i,
    /\b(i'?m presenting this case to illustrate|this case serves as a good example|this presentation focuses on)\b/i,
    /\b(this case underscores)\b/i,

    // Informal/Conversational
    /\b(so,?\s*i saw a patient (today|recently) with|the patient i met (today|recently) presented with)\b/i,
    /\b(i wanted to go over a case i saw involving?|i recently assessed a patient who came in with)\b/i,
    /\b(the patient i'?ll be talking about presented with|earlier today,?\s*i saw a patient with)\b/i,
    /\b(this morning,?\s*we admitted a patient with|i encountered a patient with)\b/i,
    /\b(i'd like to walk you through a case of|let me tell you about a patient who came in for)\b/i,

    // Additional concise patterns
    /\b(presenting a case of|i'?m presenting|this is a case of|presenting case)\b/i
  ];

  const hasChiefComplaintFormat = chiefComplaintPatterns.some(pattern => pattern.test(firstSentences));

  // Also check if any complaint-like content is mentioned (not just format)
  // Look for medical terms, symptoms, or the actual chief complaint
  const hasAnyComplaintContent = expectedComplaint
    ? firstSentences.toLowerCase().includes(expectedComplaint)
    : /\b(pain|ache|complaint|symptom|problem|issue|shortness|breathing|chest|abdominal|headache|fever|cough|nausea)\b/i.test(firstSentences);

  // Check for age (various formats: "25-year-old", "25 year old", "25 years old", etc.)
  const ageMatches = firstSentences.match(/\b(\d{1,3})[\s-]*(year[\s-]*old|yo|y\/o)\b/i);
  const mentionedAge = ageMatches ? parseInt(ageMatches[1]) : null;

  // Check for biological sex
  const sexPattern = /\b(male|female|man|woman)\b/i;
  const sexMatch = firstSentences.match(sexPattern);
  const mentionedSex = sexMatch ? sexMatch[0].toLowerCase() : null;

  // Check for patient name
  // Look for common patterns: "Mr./Mrs./Ms. Name", "Name, a", "patient Name", or just proper names
  let mentionedPatientName: string | null = null;

  // Pattern 1: Mr./Mrs./Ms./Dr. followed by a capitalized name
  const titleNamePattern = /\b(Mr\.?|Mrs\.?|Ms\.?|Dr\.?)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)/;
  const titleMatch = firstSentences.match(titleNamePattern);
  if (titleMatch) {
    mentionedPatientName = titleMatch[2].trim();
  }

  // Pattern 2: Look for capitalized names (first and last name)
  if (!mentionedPatientName) {
    const namePattern = /\b([A-Z][a-z]+\s+[A-Z][a-z]+)\b/g;
    const nameMatches = firstSentences.match(namePattern);
    if (nameMatches) {
      // Filter out common false positives like medical terms
      const filteredNames = nameMatches.filter(name =>
        !/(Emergency|Department|Medical|University|General|Hospital|Doctor|Patient|Nurse)/i.test(name)
      );
      if (filteredNames.length > 0) {
        mentionedPatientName = filteredNames[0].trim();
      }
    }
  }

  // Normalize sex terms for comparison
  const normalizeSex = (sex: string | null): string | null => {
    if (!sex) return null;
    if (sex.includes('male') || sex === 'man') return 'male';
    if (sex.includes('female') || sex === 'woman') return 'female';
    return sex;
  };

  const hasChiefComplaint = hasChiefComplaintFormat || hasAnyComplaintContent;
  const hasAge = mentionedAge !== null;
  const hasSex = mentionedSex !== null;

  // Check accuracy
  const ageCorrect = !expectedAge || !hasAge || mentionedAge === expectedAge;
  const sexCorrect = !expectedSex || !hasSex || normalizeSex(mentionedSex) === normalizeSex(expectedSex);

  // Check patient name accuracy (only for known reference cases)
  const shouldCheckName = (isArnoldPeterson || isPeterBrooks) && expectedPatientName;
  let nameCorrect = true;
  if (shouldCheckName && mentionedPatientName && expectedPatientName) {
    // Normalize names for comparison (case-insensitive)
    const normalizedMentioned = mentionedPatientName.toLowerCase().trim();
    const normalizedExpected = expectedPatientName.toLowerCase().trim();
    nameCorrect = normalizedMentioned === normalizedExpected;
  }

  if (hasChiefComplaint && hasAge && hasSex) {
    if (ageCorrect && sexCorrect && nameCorrect) {
      feedback.push("✔ You clearly presented the chief complaint and demographics using an acceptable format.");
    } else {
      // Report each error separately
      if (!nameCorrect && shouldCheckName) {
        feedback.push(`⚠ Incorrect patient name (stated ${mentionedPatientName || 'unknown'}, expected ${expectedPatientName})`);
        inaccuracies.push(`Patient name incorrect: stated ${mentionedPatientName || 'unknown'}, expected ${expectedPatientName}`);
      }
      if (!ageCorrect) {
        feedback.push(`⚠ Incorrect age (stated ${mentionedAge}, expected ${expectedAge})`);
        inaccuracies.push(`Age incorrect: stated ${mentionedAge}, expected ${expectedAge}`);
      }
      if (!sexCorrect) {
        feedback.push(`⚠ Incorrect sex (stated ${mentionedSex}, expected ${expectedSex})`);
        inaccuracies.push(`Sex incorrect: stated ${mentionedSex}, expected ${expectedSex}`);
      }
    }
  } else {
    const missing: string[] = [];
    if (!hasChiefComplaint) missing.push('complaint');
    if (!hasAge) missing.push('age');
    if (!hasSex) missing.push('sex');
    feedback.push(`⚠ Missing ${missing.join(', ')}. Complaint, age, sex should be included in the first 1-3 sentences`);
  }

  // Chief Complaint Part B - Clinical Context
  // Check for relevant context within the frame (first ~200-300 words or early sentences)
  const frameText = transcript.slice(0, 800);

  // Check if chief complaint is present in frame
  const hasComplaintInFrame = hasChiefComplaint;

  // Check for context indicators (timing, precipitating event, comorbidity, relevant circumstance)
  const contextPatterns = {
    timing: /(today|yesterday|hours? ago|days? ago|weeks? ago|months? ago|recently|this (morning|afternoon|evening)|last (night|week|month)|for the (past|last))/i,
    precipitatingEvent: /(after|following|during|while|when|since|triggered by|brought on by|started (when|after|while)|began (after|when|while))/i,
    comorbidity: /(history of|known|diagnosed with|prior|previous|with a background of|with underlying|chronic|longstanding)/i,
    relevantCircumstance: /(at rest|on exertion|with activity|post-operative|post-partum|following surgery|during pregnancy|at work|at home)/i
  };

  const hasTimingContext = contextPatterns.timing.test(frameText);
  const hasPrecipitatingEvent = contextPatterns.precipitatingEvent.test(frameText);
  const hasComorbidity = contextPatterns.comorbidity.test(frameText);
  const hasRelevantCircumstance = contextPatterns.relevantCircumstance.test(frameText);

  const hasAnyContext = hasTimingContext || hasPrecipitatingEvent || hasComorbidity || hasRelevantCircumstance;

  // Evaluate clinical relevance of context using pattern matching
  // Check if context is clinically aligned with common presentations
  let contextClinicallyRelevant = false;

  if (hasAnyContext) {
    // For specific known cases, check for expected contexts
    if (isArnoldPeterson) {
      // Chest pain case - look for cardiac risk factors, exertional triggers, timing
      const relevantContexts = [
        /(chest pain).*(exertion|activity|exercise|chasing|dog|physical)/i,
        /(chest pain).*(history of|known|diagnosed with).*(hypertension|htn|high blood pressure|smoking|smoker)/i,
        /(chest pain).*(yesterday|hours? ago|today)/i,
        /(exertion|activity|exercise).*(chest pain)/i,
        /(history of|known).*(hypertension|smoking).*(chest pain)/i
      ];
      contextClinicallyRelevant = relevantContexts.some(pattern => pattern.test(frameText));
    } else if (isPeterBrooks) {
      // Abdominal pain case - look for surgical history, timing, GI symptoms
      const relevantContexts = [
        /(abdominal pain).*(days? ago|yesterday|recently|for the past|last)/i,
        /(abdominal pain).*(history of|prior|previous).*(surgery|surgical|operation|cholecystectomy|hernia)/i,
        /(abdominal pain).*(vomit|nausea|constipat|distend)/i,
        /(prior|previous).*(surgery|surgical).*(abdominal pain)/i,
        /(history of).*(aortic|aneurysm|hypertension).*(abdominal pain)/i
      ];
      contextClinicallyRelevant = relevantContexts.some(pattern => pattern.test(frameText));
    } else {
      // For generic cases, accept any context that follows common clinical patterns
      // Context is relevant if it includes timing + complaint, or comorbidity + complaint, etc.
      const genericRelevantPatterns = [
        // Timing with complaint
        /(pain|ache|shortness|breathing|chest|abdominal|headache|fever|cough|nausea).*(today|yesterday|hours? ago|days? ago|recently)/i,
        /(today|yesterday|hours? ago|days? ago|recently).*(pain|ache|shortness|breathing|chest|abdominal|headache|fever|cough|nausea)/i,
        // Comorbidity with complaint
        /(history of|known|diagnosed with|prior).*(diabetes|hypertension|cardiac|cancer|copd|asthma).*(pain|ache|shortness|breathing)/i,
        // Precipitating event with complaint
        /(after|during|while|following).*(exercise|activity|eating|surgery|trauma).*(pain|ache|shortness|breathing)/i
      ];
      contextClinicallyRelevant = genericRelevantPatterns.some(pattern => pattern.test(frameText));
    }
  }

  // Score and provide feedback for Part B
  let partBScore = 0;
  if (hasComplaintInFrame && hasAnyContext && contextClinicallyRelevant) {
    partBScore = 1;
    feedback.push("✔ You clearly stated the patient's chief complaint and included relevant clinical context");
  } else if (!hasComplaintInFrame || !hasAnyContext) {
    feedback.push("⚠ Missing either the chief complaint or relevant context. Ensure both are included early in your presentation");
  } else if (hasAnyContext && !contextClinicallyRelevant) {
    feedback.push("⚠ Context provided may not be clinically relevant to the chief complaint. Consider including timing, precipitating events, or pertinent comorbidities");
  }

  // Chief Complaint Part C - Why patient presented TODAY
  // Check for triggers, worsening symptoms, new changes, or concern prompting care
  const presentationTriggerPatterns = [
    // Sudden onset
    /(sudden|suddenly|acute|abrupt)/i,
    // Progressive/worsening
    /(worsen|worse|worsening|progressively|progressive|getting worse|increasing|increased)/i,
    // New symptoms
    /(new|started|began|developed|onset|appeared)/i,
    // Severity changes
    /(severe|unbearable|intolerable|can't take|couldn't handle|never.*this bad|worst)/i,
    // Unable to function
    /(unable to|couldn't|can't|difficulty|trouble|prevent.*from)/i,
    // Prompting factors
    /(prompted|brought.*in|came.*in|presented|seeking|concerned|worried|decided to come)/i,
    // Time-based urgency
    /(today|this morning|this afternoon|tonight|now|currently|at this time)/i,
    // Persistence despite intervention
    /(not improving|not better|no relief|unrelieved|despite|failed to)/i
  ];

  const hasPresentationTrigger = presentationTriggerPatterns.some(pattern => pattern.test(frameText));

  let partCScore = 0;
  if (hasPresentationTrigger) {
    partCScore = 1;
    feedback.push("✔ You clearly stated what prompted the patient to come in today");
  } else {
    feedback.push("⚠ No clear reason for presentation detected. Include what changed or worsened to prompt this visit");
  }

  // Part D - Age (separate scoring from Part A)
  // Check for numeric age (e.g., "55-year-old", "55 year old", "55 years old", "55 yo", "55 y/o")
  // OR descriptive age (e.g., "man in his fifties", "woman in her sixties", "elderly", "young adult")
  const hasNumericAge = /\b(\d{1,3})[\s-]*(year[\s-]*old|yo|y\/o)\b/i.test(frameText);
  const hasDescriptiveAge = /(in (his|her|their) (twenties|thirties|forties|fifties|sixties|seventies|eighties|nineties)|elderly|geriatric|young adult|middle[- ]aged|adolescent|pediatric|infant)/i.test(frameText);

  const hasAgeStated = hasNumericAge || hasDescriptiveAge;

  let partDScore = 0;
  if (hasAgeStated) {
    partDScore = 1;
    feedback.push("✔ You clearly stated the patient's age");
  } else {
    feedback.push("⚠ Patient's age not stated. Include this in your introductory sentence");
  }

  // Part E - Biological Sex
  // Rule: The student must explicitly state the patient's biological sex (e.g., "male," "female," "man," "woman")
  // Gender identity can be included but cannot replace biological sex
  // Scored: +1 point if biological sex is explicitly mentioned
  const biologicalSexPattern = /\b(male|female|man|woman)\b/i;
  const hasBiologicalSex = biologicalSexPattern.test(frameText);

  let partEScore = 0;
  if (hasBiologicalSex) {
    partEScore = 1;
    feedback.push("✔ You clearly stated the patient's biological sex");
  } else {
    feedback.push("⚠ Incorrect: Biological sex not mentioned. Include this early for clarity");
  }

  // Part F - Filler Word Control
  // Rule: Must avoid excessive filler words. Limit is two or fewer filler words per sentence.
  // Filler words: "um," "uh," "like," "you know," "so," "basically," "literally," "kind of," "sort of," "actually," "honestly"
  // Scored: +1 point if compliant; 0 if excessive filler use detected
  const fillerWords = [
    'um', 'uh', 'like', 'you know', 'so', 'basically', 'literally',
    'kind of', 'sort of', 'actually', 'honestly'
  ];

  // Count filler words in transcript
  const fillerCounts: { [key: string]: number } = {};
  let totalFillerCount = 0;

  fillerWords.forEach(filler => {
    // Create pattern that matches the filler as a whole word or phrase
    const pattern = new RegExp(`\\b${filler.replace(' ', '\\s+')}\\b`, 'gi');
    const matches = transcript.match(pattern);
    const count = matches ? matches.length : 0;
    if (count > 0) {
      fillerCounts[filler] = count;
      totalFillerCount += count;
    }
  });

  // Count sentences
  const sentenceCount = (transcript.match(/[.!?]+/g) || []).length || 1;
  const fillerWordsPerSentence = totalFillerCount / sentenceCount;

  let partFScore = 0;
  if (fillerWordsPerSentence <= 2) {
    partFScore = 1;
    feedback.push("✔ Excellent speech control. No unnecessary filler words detected");
  } else {
    // Get top 3-5 most common filler words for feedback
    const sortedFillers = Object.entries(fillerCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([word, count]) => `"${word}" (${count}x)`)
      .join(', ');

    feedback.push(`⚠ Incorrect: Too many filler words. Limit to two per sentence and use short pauses instead. Most common: ${sortedFillers}`);
  }

  // Signposting and Organization (Tip — Not Scored)
  // Rule: If student jumps to another topic (e.g., medications, social history), they must signpost the transition
  // and state intent to return (e.g., "I'll quickly list medications, then return to the chief complaint")
  // This is feedback only; no scoring impact

  // Topics that are outside typical FRAME content
  const offTopicPatterns = {
    medications: /\b(medication|drug|prescri|taking|on|started on|current meds)\b/i,
    socialHistory: /\b(smok|tobacco|alcohol|drink|recreational|drugs|occupation|work|living|married|social history)\b/i,
    familyHistory: /\b(family history|father|mother|brother|sister|relative|hereditary|genetic|runs in the family)\b/i,
    pastMedicalHistory: /\b(past medical|pmh|history of|diagnosed with|prior|previous)\b/i,
    physicalExam: /\b(on exam|physical exam|inspection|palpation|auscultation|vital signs|temperature|blood pressure|heart rate)\b/i,
    labs: /\b(lab|laboratory|blood work|cbc|bmp|troponin|test results|imaging|x-ray|ct|mri)\b/i,
  };

  // Signposting language patterns
  const signpostingPatterns = [
    /\b(i'?ll (quickly|briefly) (mention|list|go over|cover|discuss)|then (return|come back|go back) to)\b/i,
    /\b(before (continuing|moving on)|after (that|this)|let me (quickly|briefly))\b/i,
    /\b(to give you context|for context|just to mention|worth noting)\b/i,
    /\b(i'?ll (circle|get) back to|returning to|back to the)\b/i,
    /\b(parenthetically|as an aside|side note)\b/i,
  ];

  // Check if transcript jumps to off-topic content within FRAME section (first 800 chars)
  let hasOffTopicJump = false;
  let offTopicFound = '';

  for (const [topic, pattern] of Object.entries(offTopicPatterns)) {
    if (pattern.test(frameText)) {
      // Found off-topic content in FRAME
      hasOffTopicJump = true;
      offTopicFound = topic;
      break;
    }
  }

  if (hasOffTopicJump) {
    // Check if signposting was used
    const hasSignposting = signpostingPatterns.some(pattern => pattern.test(frameText));

    if (hasSignposting) {
      feedback.push("◯ Good job signposting your transition — clearly stating your return to the main topic improved organization");
    } else {
      feedback.push("Tip: Consider signposting transitions when jumping between topics to help your preceptor follow your presentation logically");
    }
  }

  // Chief Complaint Pause (Tip — Not Scored)
  // Rule: Include a 2–3 second pause immediately after the chief complaint before continuing
  // This is feedback only; no scoring impact
  // Note: Audio analysis for pause detection is not available in transcript-only analysis
  // We provide this as a general tip when a chief complaint is detected

  if (hasChiefComplaint) {
    // Check for indicators of a pause after chief complaint
    // Look for period followed by new sentence, or explicit pause markers
    // This is a best-effort detection since we don't have audio timing data

    // Extract the chief complaint sentence (looking for the sentence containing age/sex/complaint)
    const ccSentenceMatch = firstSentences.match(/[^.!?]*\d{1,3}[\s-]*(year[\s-]*old|yo|y\/o)[^.!?]*(male|female|man|woman)[^.!?]*[.!?]/i);

    if (ccSentenceMatch) {
      const ccSentence = ccSentenceMatch[0];
      const ccIndex = transcript.indexOf(ccSentence);

      if (ccIndex !== -1) {
        // Get text immediately after chief complaint
        const afterCC = transcript.slice(ccIndex + ccSentence.length, ccIndex + ccSentence.length + 200);

        // Look for pause indicators: ellipsis, multiple periods, explicit pause mentions, or natural sentence break
        const pauseIndicators = [
          /^[\s.]{3,}/,  // Multiple periods or spaces
          /^\s*\.{2,}/,  // Ellipsis
          /^\s*(pause|\.\.\.)/i,  // Explicit pause mention
        ];

        const hasPauseIndicator = pauseIndicators.some(pattern => pattern.test(afterCC));

        // Also check if there's a natural break (new paragraph or significant spacing)
        const hasNaturalBreak = /^\s{10,}|\n\n/.test(afterCC);

        if (hasPauseIndicator || hasNaturalBreak) {
          feedback.push("◯ Good job pausing after the chief complaint — this allows time for information to be processed");
        } else {
          feedback.push("Tip: Consider adding a 2–3 second pause after the chief complaint to give the listener time to absorb it");
        }
      } else {
        // If we can't find the exact location, provide general tip
        feedback.push("Tip: Consider adding a 2–3 second pause after the chief complaint to give the listener time to absorb it");
      }
    } else {
      // If chief complaint format is present but we can't identify the exact sentence, provide general tip
      feedback.push("Tip: Consider adding a 2–3 second pause after the chief complaint to give the listener time to absorb it");
    }
  }

  // Demographics Pause (Tip — Not Scored)
  // Rule: Include a 2–3 second pause after stating demographics (age and sex) before continuing
  // This is feedback only; no scoring impact
  // Note: Audio analysis for pause detection is not available in transcript-only analysis

  if (hasAge && hasBiologicalSex) {
    // Try to find the demographics statement (age and sex together)
    const demographicsPattern = /\d{1,3}[\s-]*(year[\s-]*old|yo|y\/o)[^.!?]*(male|female|man|woman)/i;
    const demographicsMatch = firstSentences.match(demographicsPattern);

    if (demographicsMatch) {
      const demographicsText = demographicsMatch[0];
      const demographicsIndex = transcript.indexOf(demographicsText);

      if (demographicsIndex !== -1) {
        // Get text immediately after demographics
        const afterDemographics = transcript.slice(
          demographicsIndex + demographicsText.length,
          demographicsIndex + demographicsText.length + 200
        );

        // Look for pause indicators
        const pauseIndicators = [
          /^[\s.]{3,}/,
          /^\s*\.{2,}/,
          /^\s*(pause|\.\.\.)/i,
        ];

        const hasPauseIndicator = pauseIndicators.some(pattern => pattern.test(afterDemographics));
        const hasNaturalBreak = /^\s{10,}|\n\n/.test(afterDemographics);

        if (hasPauseIndicator || hasNaturalBreak) {
          feedback.push("◯ Good job pausing after demographics — it provides a clear transition and helps the listener retain key details");
        } else {
          feedback.push("Tip: Consider adding a short pause after demographics to improve pacing and clarity");
        }
      } else {
        feedback.push("Tip: Consider adding a short pause after demographics to improve pacing and clarity");
      }
    } else {
      feedback.push("Tip: Consider adding a short pause after demographics to improve pacing and clarity");
    }
  }

  return {
    score: partBScore + partCScore + partDScore + partEScore + partFScore,
    maxScore: 5,
    feedback,
    inaccuracies,
    passed: true
  };
}

function evaluateContext(transcript: string): StepScore {
  return {
    score: 0,
    maxScore: 0,
    feedback: [],
    passed: true
  };
}

function evaluateStory(transcript: string, medicalCase: MedicalCase): StepScore {
  const feedback: string[] = [];
  const inaccuracies: string[] = [];
  const isArnoldPeterson = medicalCase.id === ARNOLD_PETERSON_CASE_ID;
  const isPeterBrooks = medicalCase.id === PETER_BROOKS_CASE_ID;

  if (!isArnoldPeterson && !isPeterBrooks) {
    return {
      score: 24,
      maxScore: 24,
      feedback: [],
      inaccuracies: [],
      passed: true
    };
  }

  const transcriptLower = transcript.toLowerCase();

  // Signposting Check - Must introduce HPI with clear transition phrase
  // Check for acceptable signposting variations at the beginning of HPI section
  const signpostingPatterns = [
    /\bthe story is\b/i,
    /\bthe patient'?s story is\b/i,
    /\bhere'?s what happened\b/i,
    /\bthis is the story\b/i,
    /\bthe history is as follows\b/i,
    /\blet me tell you what happened\b/i,
    /\bto begin,?\s+here'?s\b/i,
    /\bthe presenting complaint is followed by\b/i,
    /\bthis is what the patient\b/i,
    /\baccording to the patient,?\s+the history\b/i,
    /\bthe patient reports\b/i,
    /\bthe patient describes\b/i,
    /\bthe patient states\b/i,
    /\bthe patient presents with\b/i,
    /\bregarding the history\b/i,
    /\bmoving (on|forward) to the history\b/i,
    /\bnow for the history\b/i,
    /\bstarting with the history\b/i,
  ];

  const hasSignposting = signpostingPatterns.some(pattern => pattern.test(transcript));

  if (hasSignposting) {
    feedback.push("✔ Clear signposting when transitioning to reporting the HPI is demonstrated");
  } else {
    feedback.push("⚠ No clear transition into the HPI is demonstrated");
  }

  // Chronological Order Check - HPI must follow: onset → evolution → current state
  // Check for onset indicators
  const onsetPatterns = [
    /\b(started|began|developed|onset|first|initial|initially|originally|came on|presented with)\b/i,
    /\b(yesterday|days? ago|weeks? ago|months? ago|years? ago|hours? ago)\b/i,
    /\b(sudden|suddenly|acute|abrupt)/i,
    /\b(when|while|during|after)\b/i,
  ];

  // Check for evolution/progression indicators
  const evolutionPatterns = [
    /\b(then|after|subsequently|later|following|next|since then|over time)\b/i,
    /\b(worsen|worse|worsening|progress|progressed|progressive|increased|increasing)\b/i,
    /\b(improved|better|decreased|resolved|subsided)\b/i,
    /\b(continued|persistent|ongoing|remained)\b/i,
    /\b(changed|evolved|developed into)\b/i,
  ];

  // Check for current state indicators
  const currentStatePatterns = [
    /\b(now|currently|today|at present|at this time|right now)\b/i,
    /\b(is|are|feels?|experiencing|having)\b/i,
    /\b(still|continue to|ongoing)\b/i,
  ];

  const hasOnset = onsetPatterns.some(pattern => pattern.test(transcript));
  const hasEvolution = evolutionPatterns.some(pattern => pattern.test(transcript));
  const hasCurrentState = currentStatePatterns.some(pattern => pattern.test(transcript));

  // Check if elements appear in correct order by finding their positions
  if (hasOnset && hasEvolution && hasCurrentState) {
    // Find approximate positions of each element
    let onsetIndex = -1;
    let evolutionIndex = -1;
    let currentIndex = -1;

    for (const pattern of onsetPatterns) {
      const match = transcript.match(pattern);
      if (match && match.index !== undefined && (onsetIndex === -1 || match.index < onsetIndex)) {
        onsetIndex = match.index;
      }
    }

    for (const pattern of evolutionPatterns) {
      const match = transcript.match(pattern);
      if (match && match.index !== undefined && (evolutionIndex === -1 || match.index < evolutionIndex)) {
        evolutionIndex = match.index;
      }
    }

    for (const pattern of currentStatePatterns) {
      const match = transcript.match(pattern);
      if (match && match.index !== undefined && (currentIndex === -1 || match.index < currentIndex)) {
        currentIndex = match.index;
      }
    }

    // Check if they appear in chronological order
    if (onsetIndex < evolutionIndex && evolutionIndex < currentIndex) {
      feedback.push("✔ The events are presented in chronological order (onset → evolution → current state)");
    } else {
      feedback.push("⚠ Events are out of sequence. Reorganize the HPI chronologically");
    }
  } else {
    // Missing one or more timeline elements
    const missing: string[] = [];
    if (!hasOnset) missing.push("onset");
    if (!hasEvolution) missing.push("evolution");
    if (!hasCurrentState) missing.push("current state");
    feedback.push(`⚠ Chronological flow cannot be verified; missing: ${missing.join(", ")}`);
  }

  if (isArnoldPeterson) {
    const ref = ARNOLD_PETERSON_REFERENCE;

    // Strict validation against reference data
    const hpiChecks = {
      onset: /((yesterday|hours ago|hour ago|3 hour|three hour|exertion|activity|exercise|chasing|dog|physical))/i.test(transcript),
      location: /(central|retrosternal|chest|substernal|midsternal)/i.test(transcript),
      duration: /(3 hour|three hour|constant|persistent|ongoing|continuous)/i.test(transcript),
      characteristics: /(squeez|pressure|crush|tight|heavy|constrict)/i.test(transcript),
      radiation: /(shoulder|arm|neck|jaw|radiat|spread)/i.test(transcript),
      severity: /(7\s?\/\s?10|seven.*ten|moderate|severe)/i.test(transcript),
    };

    // Check for incorrect details
    const onsetMentioned = /(yesterday|hours ago|hour ago|day ago|days ago)/i.test(transcript);
    const wrongOnset = onsetMentioned && !/(yesterday|3 hour|three hour)/i.test(transcript);

    const locationMentioned = /(left|right|lateral|epigastric|chest)/i.test(transcript);
    const wrongLocation = locationMentioned && !/(central|retrosternal|substernal|midsternal|middle)/i.test(transcript);

    const radiationMentioned = /(radiat|spread|extend)/i.test(transcript);
    const wrongRadiation = radiationMentioned && !/(shoulder|both shoulder)/i.test(transcript);

    // Check for incorrect severity rating
    const severityMatch = transcript.match(/(\d+)\s*\/\s*10/i);
    const wrongSeverity = severityMatch && parseInt(severityMatch[1]) !== 7;

    // Check for incorrect pain characteristics
    const wrongCharacteristics = [];
    if (/(sharp|stabbing|knife.*like)/i.test(transcript) && !/(pressure|squeez|crush)/i.test(transcript)) {
      wrongCharacteristics.push('sharp/stabbing (should be pressure-like/squeezing)');
    }
    if (/(burning)/i.test(transcript) && !/(pressure|squeez|crush)/i.test(transcript)) {
      wrongCharacteristics.push('burning (should be pressure-like/squeezing)');
    }

    // Validate key details - separate missing vs inaccurate
    if (!hpiChecks.onset) {
      feedback.push('Missing: Pain onset (yesterday, worsened 3 hours ago with exertion/chasing dog)');
    }
    if (wrongOnset) {
      inaccuracies.push('Inaccurate: Pain began yesterday, became severe 3 hours ago');
    }
    if (!hpiChecks.location) {
      feedback.push('Missing: Pain location (central/retrosternal chest)');
    }
    if (wrongLocation) {
      inaccuracies.push('Inaccurate: Pain is central/retrosternal, not lateral or epigastric');
    }
    if (!hpiChecks.characteristics) {
      feedback.push('Missing: Pain quality (squeezing, pressure-like)');
    }
    if (wrongCharacteristics.length > 0) {
      inaccuracies.push(`Inaccurate pain characteristics: Stated ${wrongCharacteristics.join(', ')}`);
    }
    if (!hpiChecks.radiation) {
      feedback.push('Missing: Pain radiation (to both shoulders)');
    }
    if (wrongRadiation) {
      inaccuracies.push('Inaccurate: Pain radiates to both shoulders, not to other locations');
    }
    if (!hpiChecks.severity) {
      feedback.push('Missing: Pain severity (7/10)');
    }
    if (wrongSeverity && severityMatch) {
      inaccuracies.push(`Severity incorrect: Stated ${severityMatch[1]}/10, expected 7/10`);
    }
  }

  if (isPeterBrooks) {
    const ref = PETER_BROOKS_REFERENCE;

    // Strict validation against reference data
    const hpiChecks = {
      onset: /(days ago|few days|several days|granddaughter|birthday)/i.test(transcript),
      location: /(diffuse|generalized|all over|throughout|abdomen|abdominal)/i.test(transcript),
      duration: /(days|several days|few days)/i.test(transcript),
      characteristics: /(cramp|colicky|waxing|waning|intermittent|deep)/i.test(transcript),
      severity: /(severe|bad|worst|never.*this bad)/i.test(transcript),
    };

    // Check associated symptoms
    const symptomChecks = {
      vomiting: /(vomit|emesis|throwing up)/i.test(transcript),
      constipation: /(constipat|no bowel movement|no stool|no bm)/i.test(transcript),
      distension: /(distend|bloat|swollen|enlarged abdomen)/i.test(transcript),
      flatus: /(gas|flatus|passing gas|minimal gas)/i.test(transcript),
    };

    // Check for incorrect details
    const wrongLocation = /(right upper|left upper|ruq|luq|right lower|left lower|rlq|llq|localized)/i.test(transcript) && !/(diffuse|generalized)/i.test(transcript);

    // Validate key details - separate missing vs inaccurate
    if (!hpiChecks.onset) {
      feedback.push('Missing: Pain onset (a few days ago)');
    }
    if (!hpiChecks.location) {
      feedback.push('Missing: Pain location (diffuse/generalized abdominal pain)');
    }
    if (wrongLocation) {
      inaccuracies.push('Inaccurate: Pain is diffuse/generalized, not localized to one quadrant');
    }
    if (!hpiChecks.characteristics) {
      feedback.push('Missing: Pain quality (cramping, colicky, waxing and waning)');
    }
    if (!hpiChecks.severity) {
      feedback.push('Missing: Pain severity (severe, "never had it this bad before")');
    }
    if (!symptomChecks.vomiting) {
      feedback.push('Missing: Vomiting (key symptom)');
    }
    if (!symptomChecks.constipation) {
      feedback.push('Missing: Constipation/no bowel movement for several days');
    }
    if (!symptomChecks.distension) {
      feedback.push('Missing: Abdominal distension');
    }
  }

  return {
    score: 24,
    maxScore: 24,
    feedback,
    inaccuracies,
    passed: true
  };
}

function evaluatePertinentFindings(transcript: string, medicalCase: MedicalCase): StepScore {
  const feedback: string[] = [];
  const inaccuracies: string[] = [];
  const isArnoldPeterson = medicalCase.id === ARNOLD_PETERSON_CASE_ID;
  const isPeterBrooks = medicalCase.id === PETER_BROOKS_CASE_ID;

  if (!isArnoldPeterson && !isPeterBrooks) {
    return {
      score: 0,
      maxScore: 0,
      feedback: [],
      inaccuracies: [],
      passed: true
    };
  }

  const transcriptLower = transcript.toLowerCase();

  if (isArnoldPeterson) {
    const ref = ARNOLD_PETERSON_REFERENCE;

    // Check pertinent positives
    const pertinentPositivesChecks = {
      exertionalOnset: /(exertion|activity|exercise|chasing)/i.test(transcript),
      pressureQuality: /(pressure|squeez|crush|tight)/i.test(transcript),
      radiation: /(radiat|shoulder)/i.test(transcript),
      persistent: /(persistent|constant|ongoing|continuous)/i.test(transcript),
      hypertension: /(hypertension|htn|high blood pressure)/i.test(transcript),
      dyspnea: /(dyspnea|short.*breath|breath.*short|sob)/i.test(transcript),
      reflux: /(reflux|gerd|gastroesophageal)/i.test(transcript),
    };

    if (!pertinentPositivesChecks.exertionalOnset) {
      feedback.push('Missing pertinent positive: Exertional onset (pain started with physical activity)');
    }
    if (!pertinentPositivesChecks.pressureQuality) {
      feedback.push('Missing pertinent positive: Pressure quality of pain');
    }
    if (!pertinentPositivesChecks.radiation) {
      feedback.push('Missing pertinent positive: Radiation to shoulders');
    }
    if (!pertinentPositivesChecks.persistent) {
      feedback.push('Missing pertinent positive: Persistent pain');
    }
    if (!pertinentPositivesChecks.hypertension) {
      feedback.push('Missing pertinent positive: Known hypertension');
    }
    if (!pertinentPositivesChecks.dyspnea) {
      feedback.push('Missing pertinent positive: Transient dyspnea with exertion');
    }
    if (!pertinentPositivesChecks.reflux) {
      feedback.push('Missing pertinent positive: Known reflux disease');
    }

    // Check for INCORRECT positives (stating something that should be negative)
    const incorrectPositives: string[] = [];
    if (/(had.*diaphoresis|was.*sweating|profuse.*sweat|diaphoretic)/i.test(transcript)) {
      incorrectPositives.push('diaphoresis (patient had NO diaphoresis)');
      inaccuracies.push('Inaccurate: Patient had NO diaphoresis/sweating');
    }
    if (/(had.*syncope|passed.*out|lost.*consciousness|fainted)/i.test(transcript) && !/(no.*syncope)/i.test(transcript)) {
      incorrectPositives.push('syncope (patient had NO syncope)');
      inaccuracies.push('Inaccurate: Patient had NO syncope');
    }
    if (/(had.*palpitation|racing.*heart|heart.*racing)/i.test(transcript) && !/(no.*palpitation)/i.test(transcript)) {
      incorrectPositives.push('palpitations (patient had NO palpitations)');
      inaccuracies.push('Inaccurate: Patient had NO palpitations');
    }
    if (/(prior.*mi|previous.*heart.*attack|history.*mi)/i.test(transcript) && !/(no.*prior.*mi|no.*previous.*mi|no.*history.*mi)/i.test(transcript)) {
      incorrectPositives.push('prior MI (patient has NO prior MI)');
      inaccuracies.push('Inaccurate: Patient has NO prior MI');
    }
    if (/(had.*nausea|experiencing.*nausea|felt.*nausea|vomit|emesis)/i.test(transcript) && !/(no.*nausea|no.*vomit)/i.test(transcript)) {
      incorrectPositives.push('nausea/vomiting (patient had NO nausea or vomiting)');
      inaccuracies.push('Inaccurate: Patient had NO nausea or vomiting');
    }
    if (/(had.*fever|febrile|temperature.*elevated)/i.test(transcript) && !/(no.*fever|afebrile)/i.test(transcript)) {
      incorrectPositives.push('fever (patient had NO fever)');
      inaccuracies.push('Inaccurate: Patient had NO fever');
    }

    // Check key pertinent negatives
    const pertinentNegativesChecks = {
      noDiaphoresis: /(no.*diaphor|no.*sweat|deni.*sweat|without.*diaphor|without.*sweat)/i.test(transcript),
      noSyncope: /(no.*syncope|no.*pass.*out|no.*loss.*consciousness|deni.*syncope)/i.test(transcript),
      noPalpitations: /(no.*palpitation|no.*racing|deni.*palpitation)/i.test(transcript),
      noPriorMI: /(no.*prior.*mi|no.*previous.*heart attack|no.*prior.*cardiac|no.*history.*mi)/i.test(transcript),
      noPleuriticPain: /(no.*pleuritic|not.*worse.*breath|non.*pleuritic)/i.test(transcript),
      noFever: /(no.*fever|afebrile)/i.test(transcript),
      noNausea: /(no.*nausea|no.*vomit)/i.test(transcript),
    };

    if (!pertinentNegativesChecks.noDiaphoresis) {
      feedback.push('Missing pertinent negative: No diaphoresis');
    }
    if (!pertinentNegativesChecks.noSyncope) {
      feedback.push('Missing pertinent negative: No syncope');
    }
    if (!pertinentNegativesChecks.noPalpitations) {
      feedback.push('Missing pertinent negative: No palpitations');
    }
    if (!pertinentNegativesChecks.noPriorMI) {
      feedback.push('Missing pertinent negative: No prior MI');
    }
    if (!pertinentNegativesChecks.noPleuriticPain) {
      feedback.push('Missing pertinent negative: No pleuritic pain');
    }
    if (!pertinentNegativesChecks.noFever) {
      feedback.push('Missing pertinent negative: No fever');
    }
    if (!pertinentNegativesChecks.noNausea) {
      feedback.push('Missing pertinent negative: No nausea/vomiting');
    }
  }

  if (isPeterBrooks) {
    const ref = PETER_BROOKS_REFERENCE;

    // Check pertinent positives
    const pertinentPositivesChecks = {
      vomiting: /(vomit|emesis|throwing up)/i.test(transcript),
      constipation: /(constipat|no bowel movement|no stool)/i.test(transcript),
      distension: /(distend|bloat|swollen abdomen)/i.test(transcript),
      hypertension: /(hypertension|htn|high blood pressure)/i.test(transcript),
      aorticDilation: /(aort|aneurysm|dilation)/i.test(transcript),
    };

    if (!pertinentPositivesChecks.vomiting) {
      feedback.push('Missing pertinent positive: Vomiting');
    }
    if (!pertinentPositivesChecks.constipation) {
      feedback.push('Missing pertinent positive: Constipation/no bowel movements');
    }
    if (!pertinentPositivesChecks.distension) {
      feedback.push('Missing pertinent positive: Abdominal distension');
    }
    if (!pertinentPositivesChecks.hypertension) {
      feedback.push('Missing pertinent positive: Known hypertension');
    }
    if (!pertinentPositivesChecks.aorticDilation) {
      feedback.push('Missing pertinent positive: History of abdominal aortic dilation (critical for AAA consideration)');
    }

    // Check key pertinent negatives
    const pertinentNegativesChecks = {
      noFever: /(no.*fever|afebrile)/i.test(transcript),
      noHematochezia: /(no.*blood.*stool|no.*hematochezia|no.*rectal.*bleed)/i.test(transcript),
      noMelena: /(no.*melena|no.*black.*stool)/i.test(transcript),
      noChestPain: /(no.*chest.*pain)/i.test(transcript),
    };

    if (!pertinentNegativesChecks.noFever) {
      feedback.push('Missing pertinent negative: No fever');
    }
    if (!pertinentNegativesChecks.noHematochezia) {
      feedback.push('Missing pertinent negative: No blood in stool/hematochezia');
    }
    if (!pertinentNegativesChecks.noMelena) {
      feedback.push('Missing pertinent negative: No melena');
    }
    if (!pertinentNegativesChecks.noChestPain) {
      feedback.push('Missing pertinent negative: No chest pain');
    }
  }

  return {
    score: 0,
    maxScore: 0,
    feedback,
    inaccuracies,
    passed: true
  };
}

function evaluateBackground(transcript: string, medicalCase: MedicalCase): StepScore {
  const feedback: string[] = [];
  const inaccuracies: string[] = [];
  const isArnoldPeterson = medicalCase.id === ARNOLD_PETERSON_CASE_ID;
  const isPeterBrooks = medicalCase.id === PETER_BROOKS_CASE_ID;

  if (!isArnoldPeterson && !isPeterBrooks) {
    return {
      score: 0,
      maxScore: 0,
      feedback: [],
      passed: true
    };
  }

  const transcriptLower = transcript.toLowerCase();

  if (isArnoldPeterson) {
    const ref = ARNOLD_PETERSON_REFERENCE;

    // Strict PMH validation
    const pmhChecks = {
      hypertension: /(hypertension|htn|high blood pressure)/i.test(transcript),
      gerd: /(gerd|reflux|gastroesophageal)/i.test(transcript),
    };

    if (!pmhChecks.hypertension) {
      feedback.push('Missing: Hypertension (controlled on thiazide diuretic)');
    }
    if (!pmhChecks.gerd) {
      feedback.push('Missing: Gastroesophageal reflux disease (GERD)');
    }

    // Check for INCORRECT PMH that's not in the case
    const incorrectPMH = [];
    if (/(diabetes|dm|diabetic)/i.test(transcript) && !/(no.*diabetes|denies.*diabetes)/i.test(transcript)) {
      incorrectPMH.push('diabetes (not in patient history)');
    }
    if (/(prior.*mi|previous.*heart attack|history.*myocardial infarction)/i.test(transcript) && !/(no.*prior.*mi|no.*previous.*mi)/i.test(transcript)) {
      incorrectPMH.push('prior MI (patient has no history of MI)');
    }
    if (/(copd|chronic obstructive)/i.test(transcript) && !/(no.*copd)/i.test(transcript)) {
      incorrectPMH.push('COPD (not in patient history)');
    }
    if (/(asthma)/i.test(transcript) && !/(no.*asthma|denies.*asthma|brother.*asthma)/i.test(transcript)) {
      incorrectPMH.push('asthma (not in patient history - brother has asthma, not patient)');
    }
    if (incorrectPMH.length > 0) {
      inaccuracies.push(`Inaccurate PMH: Stated ${incorrectPMH.join(', ')}`);
    }

    // Check smoking history - CRITICAL for cardiac risk
    const smokingMentioned = /(smok|tobacco|cigarette|pack)/i.test(transcript);
    const packYearsMatch = transcript.match(/(\d+)\s*pack[\s-]*year/i);
    if (!smokingMentioned) {
      feedback.push('Missing: Smoking history (1 pack/day x 20 years = 20 pack-years)');
    } else {
      // Check for incorrect pack-year values
      if (packYearsMatch) {
        const statedPackYears = parseInt(packYearsMatch[1]);
        if (statedPackYears !== 20) {
          inaccuracies.push(`Smoking history incorrect: Stated ${statedPackYears} pack-years, expected 20 pack-years`);
        }
      }
    }

    // Check medications - must be EXACTLY chlorthalidone
    const chlorthalidone = /(chlorthalidone)/i.test(transcript);
    const wrongMedication = [];

    if (!chlorthalidone && /(medication|taking|prescribed)/i.test(transcript)) {
      // Check for wrong medications mentioned
      if (/(hydrochlorothiazide|hctz)/i.test(transcript)) {
        wrongMedication.push('hydrochlorothiazide (patient takes chlorthalidone, not HCTZ)');
      }
      if (/(lisinopril|enalapril|ace.*inhibitor)/i.test(transcript)) {
        wrongMedication.push('ACE inhibitor (patient only takes chlorthalidone)');
      }
      if (/(metoprolol|atenolol|beta.*blocker)/i.test(transcript)) {
        wrongMedication.push('beta-blocker (patient only takes chlorthalidone)');
      }
      if (/(amlodipine|calcium.*channel.*blocker)/i.test(transcript)) {
        wrongMedication.push('calcium channel blocker (patient only takes chlorthalidone)');
      }
      if (/(statin|atorvastatin|rosuvastatin)/i.test(transcript)) {
        wrongMedication.push('statin (not in patient medications)');
      }
      if (/(metformin)/i.test(transcript)) {
        wrongMedication.push('metformin (patient is not diabetic)');
      }
    }

    if (wrongMedication.length > 0) {
      inaccuracies.push(`Medication error: Stated ${wrongMedication.join(', ')}`);
    } else if (!chlorthalidone) {
      feedback.push('Missing: Current medication (chlorthalidone)');
    }

    // Check allergies
    const allergiesMentioned = /(allerg|nkda|no known drug)/i.test(transcript);
    const wrongAllergy = /(penicillin.*allerg|allerg.*penicillin)/i.test(transcript) && !/(brother.*penicillin|brother.*allerg)/i.test(transcript);
    if (wrongAllergy) {
      inaccuracies.push('Allergy error: Patient has no known allergies (brother has penicillin allergy, not patient)');
    } else if (!allergiesMentioned) {
      feedback.push('Missing: Allergies (none known)');
    }
  }

  if (isPeterBrooks) {
    const ref = PETER_BROOKS_REFERENCE;

    // Strict PMH validation
    const pmhChecks = {
      hypertension: /(hypertension|htn|high blood pressure)/i.test(transcript),
      aorticDilation: /(aort|aneurysm|dilation|aaa)/i.test(transcript),
      cholecystectomy: /(cholecystectomy|gallbladder.*remov|gallbladder.*surg)/i.test(transcript),
      herniaRepair: /(hernia.*repair|ventral.*hernia|abdominal.*hernia)/i.test(transcript),
    };

    if (!pmhChecks.hypertension) {
      feedback.push('Missing: Hypertension');
    }
    if (!pmhChecks.aorticDilation) {
      feedback.push('Missing: Abdominal aortic dilation (critical for ruling out AAA rupture)');
    }
    if (!pmhChecks.cholecystectomy) {
      feedback.push('Missing: Surgical history - cholecystectomy (remote)');
    }
    if (!pmhChecks.herniaRepair) {
      feedback.push('Missing: Surgical history - ventral/abdominal hernia repair (2014)');
    }

    // Check medications
    const medChecks = {
      perindopril: /(coversyl|perindopril)/i.test(transcript),
      atorvastatin: /(lipitor|atorvastatin)/i.test(transcript),
    };

    if (!medChecks.perindopril) {
      feedback.push('Missing: Medication - Coversyl (perindopril) 8 mg daily');
    }
    if (!medChecks.atorvastatin) {
      feedback.push('Missing: Medication - Lipitor (atorvastatin) 40 mg nightly');
    }

    // Check social history
    const smokingMentioned = /(never.*smok|non.*smok|no.*smok)/i.test(transcript);
    if (!smokingMentioned) {
      feedback.push('Missing: Smoking history (never smoked)');
    }

    // Check allergies
    const allergiesMentioned = /(allerg|nkda|no known)/i.test(transcript);
    if (!allergiesMentioned) {
      feedback.push('Missing: Allergies (none known)');
    }
  }

  return {
    score: 0,
    maxScore: 0,
    feedback,
    inaccuracies,
    passed: true
  };
}

function evaluateFamilyHistory(transcript: string, medicalCase: MedicalCase): StepScore {
  const feedback: string[] = [];
  const inaccuracies: string[] = [];
  const isArnoldPeterson = medicalCase.id === ARNOLD_PETERSON_CASE_ID;
  const isPeterBrooks = medicalCase.id === PETER_BROOKS_CASE_ID;

  if (!isArnoldPeterson && !isPeterBrooks) {
    return {
      score: 0,
      maxScore: 0,
      feedback: [],
      inaccuracies: [],
      passed: true
    };
  }

  const transcriptLower = transcript.toLowerCase();

  if (isArnoldPeterson) {
    const ref = ARNOLD_PETERSON_REFERENCE;

    // Check family history
    const familyHistoryChecks = {
      hypertensionFamily: /(father|uncle).*hypertension|hypertension.*(father|uncle)/i.test(transcript),
      noCoronaryDisease: /(no.*family.*coronary|no.*family.*heart|no.*premature.*cardiac)/i.test(transcript),
    };

    if (!familyHistoryChecks.hypertensionFamily) {
      feedback.push('Missing family history: Hypertension in father and uncle');
    }
    if (!familyHistoryChecks.noCoronaryDisease) {
      feedback.push('Missing pertinent negative: No family history of premature coronary disease');
    }

    // Check for incorrect family history
    const incorrectFamilyHistory = /(mother.*coronary|father.*mi|family.*heart attack|family.*cardiac arrest)/i.test(transcript);
    if (incorrectFamilyHistory) {
      inaccuracies.push('Inaccurate: No family history of premature coronary disease, PE, or dissection');
    }
  }

  if (isPeterBrooks) {
    const ref = PETER_BROOKS_REFERENCE;

    // Check family history
    const familyHistoryChecks = {
      motherColonCancer: /(mother.*colon.*cancer|mother.*colorectal)/i.test(transcript),
    };

    if (!familyHistoryChecks.motherColonCancer) {
      feedback.push('Missing family history: Mother had colon cancer');
    }

    // Check for incorrect family history
    const incorrectFamilyHistory = /(father.*cancer|brother.*cancer|sister.*cancer)/i.test(transcript) && !/(mother.*colon)/i.test(transcript);
    if (incorrectFamilyHistory) {
      inaccuracies.push('Inaccurate: Only mother had colon cancer, not other family members');
    }
  }

  return {
    score: 0,
    maxScore: 0,
    feedback,
    inaccuracies,
    passed: true
  };
}

function evaluateObjectiveData(transcript: string, medicalCase: MedicalCase): StepScore {
  const feedback: string[] = [];
  const inaccuracies: string[] = [];
  const isArnoldPeterson = medicalCase.id === ARNOLD_PETERSON_CASE_ID;
  const isPeterBrooks = medicalCase.id === PETER_BROOKS_CASE_ID;

  if (!isArnoldPeterson && !isPeterBrooks) {
    return {
      score: 20,
      maxScore: 20,
      feedback: [],
      inaccuracies: [],
      passed: true
    };
  }

  if (isArnoldPeterson) {
    const ref = ARNOLD_PETERSON_REFERENCE;

    // Strict vital signs validation
    const tempMatch = transcript.match(/(temperature|temp)[^\d]*(\d+\.?\d*)\s*(c|celsius|°c)/i);
    const hrMatch = transcript.match(/(heart rate|hr|pulse)[^\d]*(\d+)\s*(bpm|beats)/i);
    const rrMatch = transcript.match(/(respiratory rate|rr|respiration)[^\d]*(\d+)/i);
    const bpMatch = transcript.match(/(blood pressure|bp)[^\d]*(\d+)\/(\d+)/i);
    const spo2Match = transcript.match(/(oxygen|spo2|sat|o2)[^\d]*(\d+)\s*%/i);

    const temp = tempMatch ? parseFloat(tempMatch[2]) : null;
    const hr = hrMatch ? parseInt(hrMatch[2]) : null;
    const rr = rrMatch ? parseInt(rrMatch[2]) : null;
    const bpSys = bpMatch ? parseInt(bpMatch[2]) : null;
    const bpDia = bpMatch ? parseInt(bpMatch[3]) : null;
    const spo2 = spo2Match ? parseInt(spo2Match[2]) : null;

    // Validate against reference values: T=36.5, HR=90, RR=18, BP=150/80, SpO2=93
    if (temp && Math.abs(temp - 36.5) > 0.5) {
      inaccuracies.push(`Temperature incorrect: stated ${temp}°C, expected 36.5°C`);
    }
    if (hr && Math.abs(hr - 90) > 5) {
      inaccuracies.push(`Heart rate incorrect: stated ${hr} bpm, expected 90 bpm`);
    }
    if (rr && Math.abs(rr - 18) > 2) {
      inaccuracies.push(`Respiratory rate incorrect: stated ${rr}/min, expected 18/min`);
    }
    if (bpSys && Math.abs(bpSys - 150) > 5) {
      inaccuracies.push(`BP systolic incorrect: stated ${bpSys}, expected 150 mmHg`);
    }
    if (bpDia && Math.abs(bpDia - 80) > 5) {
      inaccuracies.push(`BP diastolic incorrect: stated ${bpDia}, expected 80 mmHg`);
    }
    if (spo2 && Math.abs(spo2 - 93) > 2) {
      inaccuracies.push(`SpO2 incorrect: stated ${spo2}%, expected 93%`);
    }

    // Check for ECG mention
    const ecgMentioned = /ecg|ekg|electrocardiogram/i.test(transcript);
    if (!ecgMentioned) {
      feedback.push('Missing: ECG findings (normal sinus rhythm, no ST-T abnormalities)');
    } else {
      // Check for correct ECG findings
      const normalECG = /(normal.*sinus.*rhythm|nsr)/i.test(transcript);
      const noSTChanges = /(no.*st|st.*normal|no.*abnormalit)/i.test(transcript);
      if (!normalECG) {
        feedback.push('ECG finding: Expected normal sinus rhythm');
      }
      if (!noSTChanges) {
        feedback.push('ECG finding: Expected no ST-T abnormalities');
      }
    }

    // Physical exam validation
    const cvExam = /(cardiovascular|cardiac|heart)/i.test(transcript);
    const respExam = /(respiratory|lung|breath sound|chest.*clear)/i.test(transcript);

    // Check for INCORRECT physical exam findings
    if (cvExam) {
      const normalHeart = /(normal.*s1.*s2|regular.*rhythm.*rate|no.*murmur)/i.test(transcript);
      if (!normalHeart) {
        feedback.push('Expected: Normal heart sounds (S1, S2), no murmurs/rubs/gallops');
      }

      // Check for incorrectly stated abnormal findings
      if (/(murmur|s3|s4|gallop|rub)/i.test(transcript) && !/(no.*murmur|no.*s3|no.*s4|no.*gallop|no.*rub)/i.test(transcript)) {
        inaccuracies.push('Cardiovascular exam incorrect: Patient has normal S1, S2 with no murmurs, rubs, or gallops');
      }
    }

    if (respExam) {
      const clearLungs = /(clear|normal.*breath.*sound|no.*crackle|no.*wheez)/i.test(transcript);
      if (!clearLungs) {
        feedback.push('Expected: Clear breath sounds bilaterally, no crackles/wheezes');
      }

      // Check for incorrectly stated abnormal findings
      if (/(crackle|wheez|rhonchi|stridor)/i.test(transcript) && !/(no.*crackle|no.*wheez|no.*rhonchi)/i.test(transcript)) {
        inaccuracies.push('Respiratory exam incorrect: Patient has clear breath sounds bilaterally with no adventitious sounds');
      }
    }

    // Check for incorrect ECG findings
    if (ecgMentioned) {
      if (/(st.*elevation|st.*depression|t.*wave.*inversion|q.*wave)/i.test(transcript) && !/(no.*st|st.*normal)/i.test(transcript)) {
        inaccuracies.push('ECG incorrect: Patient has normal sinus rhythm with no ST-T abnormalities');
      }
    }
  }

  if (isPeterBrooks) {
    const ref = PETER_BROOKS_REFERENCE;

    // Strict vital signs validation
    const tempMatch = transcript.match(/(temperature|temp)[^\d]*(\d+\.?\d*)\s*(c|celsius|°c)/i);
    const hrMatch = transcript.match(/(heart rate|hr|pulse)[^\d]*(\d+)\s*(bpm|beats)/i);
    const rrMatch = transcript.match(/(respiratory rate|rr|respiration)[^\d]*(\d+)/i);
    const bpMatch = transcript.match(/(blood pressure|bp)[^\d]*(\d+)\/(\d+)/i);
    const spo2Match = transcript.match(/(oxygen|spo2|sat|o2)[^\d]*(\d+)\s*%/i);

    const temp = tempMatch ? parseFloat(tempMatch[2]) : null;
    const hr = hrMatch ? parseInt(hrMatch[2]) : null;
    const rr = rrMatch ? parseInt(rrMatch[2]) : null;
    const bpSys = bpMatch ? parseInt(bpMatch[2]) : null;
    const bpDia = bpMatch ? parseInt(bpMatch[3]) : null;
    const spo2 = spo2Match ? parseInt(spo2Match[2]) : null;

    // Validate against reference values: T=36.3, HR=85, RR=18, BP=135/73, SpO2=96
    if (temp && Math.abs(temp - 36.3) > 0.5) {
      inaccuracies.push(`Temperature incorrect: stated ${temp}°C, expected 36.3°C`);
    }
    if (hr && Math.abs(hr - 85) > 5) {
      inaccuracies.push(`Heart rate incorrect: stated ${hr} bpm, expected 85 bpm`);
    }
    if (rr && Math.abs(rr - 18) > 2) {
      inaccuracies.push(`Respiratory rate incorrect: stated ${rr}/min, expected 18/min`);
    }
    if (bpSys && Math.abs(bpSys - 135) > 5) {
      inaccuracies.push(`BP systolic incorrect: stated ${bpSys}, expected 135 mmHg`);
    }
    if (bpDia && Math.abs(bpDia - 73) > 5) {
      inaccuracies.push(`BP diastolic incorrect: stated ${bpDia}, expected 73 mmHg`);
    }
    if (spo2 && Math.abs(spo2 - 96) > 2) {
      inaccuracies.push(`SpO2 incorrect: stated ${spo2}%, expected 96%`);
    }

    // Strict physical exam validation
    const examChecks = {
      distension: /(distend|distention|bloat)/i.test(transcript),
      tenderness: /(tender|diffuse.*tender|pain.*palpation)/i.test(transcript),
      bowelSounds: /(hyperactive.*bowel.*sound|bowel.*sound.*hyperactive)/i.test(transcript),
      scar: /(scar|ruq.*scar|right upper quadrant.*scar|8.*cm.*scar)/i.test(transcript),
    };

    if (!examChecks.distension) {
      feedback.push('Missing: Abdomen is distended');
    }
    if (!examChecks.tenderness) {
      feedback.push('Missing: Diffusely tender abdomen');
    }
    if (!examChecks.bowelSounds) {
      feedback.push('Missing: Hyperactive bowel sounds');
    }
    if (!examChecks.scar) {
      feedback.push('Missing: 8 cm linear scar in RUQ (from prior surgery)');
    }

    // Check for incorrect findings
    const wrongBowelSounds = /(hypoactive|absent|diminished).*bowel.*sound/i.test(transcript);
    if (wrongBowelSounds) {
      inaccuracies.push('Inaccurate: Bowel sounds are hyperactive, not hypoactive/absent');
    }

    // Check for absence of peritonitis signs
    const peritonitisChecks = {
      noGuarding: /(no.*guard|guard.*negative|absent.*guard)/i.test(transcript),
      noRebound: /(no.*rebound|rebound.*negative|absent.*rebound)/i.test(transcript),
    };

    if (peritonitisChecks.noGuarding || peritonitisChecks.noRebound) {
      feedback.push('✔ Good job noting absence of peritoneal signs');
    }
  }

  return {
    score: 20,
    maxScore: 20,
    feedback,
    inaccuracies,
    passed: true
  };
}

function evaluateAssessment(transcript: string, medicalCase: MedicalCase): StepScore {
  const feedback: string[] = [];
  const inaccuracies: string[] = [];
  const isArnoldPeterson = medicalCase.id === ARNOLD_PETERSON_CASE_ID;
  const isPeterBrooks = medicalCase.id === PETER_BROOKS_CASE_ID;

  if (!isArnoldPeterson && !isPeterBrooks) {
    return {
      score: 20,
      maxScore: 20,
      feedback: [],
      inaccuracies: [],
      passed: true
    };
  }

  const transcriptLower = transcript.toLowerCase();

  if (isArnoldPeterson) {
    const ref = ARNOLD_PETERSON_REFERENCE;

    // Strict assessment validation
    const hasACS = /(acute coronary syndrome|acs)/i.test(transcript);
    const hasAngina = /(unstable angina|angina)/i.test(transcript);
    const hasNSTEMI = /nstemi/i.test(transcript);

    if (!hasACS && !hasAngina && !hasNSTEMI) {
      feedback.push('Missing: Primary assessment should be ACS (unstable angina vs. NSTEMI)');
    }

    // Check for dangerous differentials mentioned
    const dangerousDxChecks = {
      pe: /(pulmonary embolism|pe)/i.test(transcript),
      dissection: /(aortic dissection|dissection)/i.test(transcript),
      pneumothorax: /(pneumothorax|collapsed lung)/i.test(transcript),
      pericarditis: /pericarditis/i.test(transcript),
    };

    const mentionedCount = Object.values(dangerousDxChecks).filter(v => v).length;
    if (mentionedCount < 2) {
      feedback.push('Missing: Should include dangerous differentials (PE, aortic dissection, pneumothorax, pericarditis)');
    }

    // Check for other differentials
    const otherDxChecks = {
      gerd: /(gerd|reflux)/i.test(transcript),
      msk: /(musculoskeletal|muscle|msk)/i.test(transcript),
    };

    // Check for reasoning/risk factors
    const hasReasoning = /(risk factor|exertional|pressure.*like|radiat|unrelieved|persist)/i.test(transcript);
    if (!hasReasoning) {
      feedback.push('Consider explaining reasoning: exertional, pressure-like, radiating pain + risk factors');
    }
  }

  if (isPeterBrooks) {
    const ref = PETER_BROOKS_REFERENCE;

    // Strict assessment validation
    const hasSBO = /(small bowel obstruction|sbo)/i.test(transcript);
    if (!hasSBO) {
      feedback.push('Missing: Primary assessment should be small bowel obstruction (SBO)');
    }

    // Check for etiology
    const mentionsAdhesions = /(adhesion|postoperative|post.*surgical|scar tissue)/i.test(transcript);
    if (!mentionsAdhesions) {
      feedback.push('Missing: Etiology - adhesions from prior abdominal surgeries');
    }

    // Check for dangerous differentials
    const dangerousDxChecks = {
      strangulation: /(strangulat|ischemi)/i.test(transcript),
      aaa: /(aneurysm|aortic|aaa|rupture)/i.test(transcript),
      perforation: /(perforat|perforation)/i.test(transcript),
    };

    const mentionedCount = Object.values(dangerousDxChecks).filter(v => v).length;
    if (mentionedCount < 2) {
      feedback.push('Missing: Should include dangerous differentials (strangulated SBO, AAA rupture, perforated viscus)');
    }

    // Check for reasoning
    const hasReasoning = /(prior.*surg|adhesion|vomit|constipat|distend|hyperactive)/i.test(transcript);
    if (!hasReasoning) {
      feedback.push('Consider explaining reasoning: prior surgeries, vomiting, constipation, distension, hyperactive bowel sounds');
    }
  }

  return {
    score: 20,
    maxScore: 20,
    feedback,
    inaccuracies,
    passed: true
  };
}

function evaluatePlan(transcript: string, medicalCase: MedicalCase): StepScore {
  const feedback: string[] = [];
  const inaccuracies: string[] = [];
  const isArnoldPeterson = medicalCase.id === ARNOLD_PETERSON_CASE_ID;
  const isPeterBrooks = medicalCase.id === PETER_BROOKS_CASE_ID;

  if (!isArnoldPeterson && !isPeterBrooks) {
    return {
      score: 20,
      maxScore: 20,
      feedback: [],
      inaccuracies: [],
      passed: true
    };
  }

  const transcriptLower = transcript.toLowerCase();

  if (isArnoldPeterson) {
    const ref = ARNOLD_PETERSON_REFERENCE;

    // Strict symptomatic management validation
    const symptomaticChecks = {
      nitroglycerin: /(nitro|nitroglycerin)/i.test(transcript),
      aspirin: /(aspirin|asa)/i.test(transcript),
      oxygen: /(oxygen|o2)/i.test(transcript),
      morphine: /morphine/i.test(transcript),
    };

    // Check for wrong dosages
    const nitroMatch = transcript.match(/(nitro|nitroglycerin)\s*(\d+\.?\d*)\s*(mg|mcg)/i);
    if (nitroMatch) {
      const dose = parseFloat(nitroMatch[2]);
      const unit = nitroMatch[3].toLowerCase();
      if (unit === 'mg' && dose !== 0.4) {
        inaccuracies.push(`Nitroglycerin dosage incorrect: Stated ${dose} mg, expected 0.4 mg`);
      } else if (unit === 'mcg' && dose !== 400) {
        inaccuracies.push(`Nitroglycerin dosage incorrect: Stated ${dose} mcg, expected 400 mcg (0.4 mg)`);
      }
    } else if (!symptomaticChecks.nitroglycerin) {
      feedback.push('Missing: Nitroglycerin 0.4 mg SL (if SBP ≥ 100 mmHg)');
    }

    const aspirinMatch = transcript.match(/(aspirin|asa)\s*(\d+)\s*mg/i);
    if (aspirinMatch) {
      const dose = parseInt(aspirinMatch[2]);
      if (dose !== 325 && dose !== 324) {  // Allow 324 or 325
        inaccuracies.push(`Aspirin dosage incorrect: Stated ${dose} mg, expected 325 mg`);
      }
    } else if (!symptomaticChecks.aspirin) {
      feedback.push('Missing: Aspirin 325 mg chewed');
    }

    if (!symptomaticChecks.oxygen) {
      feedback.push('Consider: Oxygen if SpO₂ < 94%');
    }

    // Lab validation
    const labChecks = {
      troponin: /(troponin|cardiac.*enzyme)/i.test(transcript),
      cbc: /(cbc|complete.*blood.*count)/i.test(transcript),
      bmp: /(bmp|basic.*metabolic|electrolyte)/i.test(transcript),
    };

    if (!labChecks.troponin) {
      feedback.push('Missing: Serial troponin I/T');
    }
    if (!labChecks.cbc) {
      feedback.push('Missing: CBC');
    }
    if (!labChecks.bmp) {
      feedback.push('Missing: BMP/electrolytes');
    }

    // Imaging validation
    const imagingChecks = {
      cxr: /(chest.*x.*ray|cxr)/i.test(transcript),
      echo: /(echo|echocardiogram)/i.test(transcript),
    };

    if (!imagingChecks.cxr) {
      feedback.push('Missing: Chest X-ray');
    }

    // Disposition validation
    const dispositionChecks = {
      admit: /(admit|admission|monitored.*bed|telemetry)/i.test(transcript),
      cardiology: /(cardiology|cardiac.*consult)/i.test(transcript),
      serialECG: /(serial.*ecg|repeat.*ecg)/i.test(transcript),
    };

    if (!dispositionChecks.admit) {
      feedback.push('Missing: Admit to monitored bed/telemetry');
    }
    if (!dispositionChecks.cardiology) {
      feedback.push('Missing: Cardiology consult');
    }
    if (!dispositionChecks.serialECG) {
      feedback.push('Missing: Serial ECGs and troponins');
    }
  }

  if (isPeterBrooks) {
    const ref = PETER_BROOKS_REFERENCE;

    // Strict symptomatic management validation
    const symptomaticChecks = {
      npo: /(npo|nil.*os|nothing.*mouth)/i.test(transcript),
      ivFluids: /(iv.*fluid|intravenous.*fluid|normal saline|ringer)/i.test(transcript),
      ngt: /(nasogastric|ng.*tube|ngt|gastric.*decompress)/i.test(transcript),
      painControl: /(pain.*control|analges|acetaminophen|tylenol)/i.test(transcript),
      antiemetic: /(antiemetic|ondansetron|zofran)/i.test(transcript),
    };

    if (!symptomaticChecks.npo) {
      feedback.push('Missing: Keep NPO (nil per os)');
    }
    if (!symptomaticChecks.ivFluids) {
      feedback.push('Missing: IV fluids (Normal Saline or Ringer\'s Lactate) for rehydration');
    }
    if (!symptomaticChecks.ngt) {
      feedback.push('Missing: Nasogastric tube (NGT) for gastric decompression');
    }
    if (!symptomaticChecks.painControl) {
      feedback.push('Missing: Pain control with acetaminophen');
    }
    if (!symptomaticChecks.antiemetic) {
      feedback.push('Missing: Antiemetic (e.g., ondansetron 4 mg IV PRN)');
    }

    // Strict lab validation
    const labChecks = {
      cbc: /(cbc|complete.*blood.*count)/i.test(transcript),
      electrolytes: /(electrolyte|bmp|basic.*metabolic)/i.test(transcript),
      lactate: /(lactate|lactic.*acid)/i.test(transcript),
      lfts: /(lft|liver.*function)/i.test(transcript),
    };

    if (!labChecks.cbc) {
      feedback.push('Missing: CBC (look for leukocytosis/anemia)');
    }
    if (!labChecks.electrolytes) {
      feedback.push('Missing: BMP/Electrolytes (assess dehydration, renal function)');
    }
    if (!labChecks.lactate) {
      feedback.push('Missing: Lactate (elevated in ischemia/strangulation)');
    }

    // Strict imaging validation
    const imagingChecks = {
      xray: /(abdominal.*x.*ray|x.*ray.*abdomen|kub)/i.test(transcript),
      ct: /(ct.*abdomen|abdominal.*ct|ct.*pelvis)/i.test(transcript),
    };

    if (!imagingChecks.xray && !imagingChecks.ct) {
      feedback.push('Missing: Abdominal imaging (X-ray and/or CT)');
    }
    if (!imagingChecks.ct) {
      feedback.push('Consider: CT abdomen/pelvis with IV contrast (confirms obstruction, identifies transition point)');
    }

    // Strict disposition validation
    const dispositionChecks = {
      admit: /(admit|admission|hospital)/i.test(transcript),
      surgery: /(surgery|surgical.*consult|general.*surgery)/i.test(transcript),
      npoFluidsContinue: /(continue.*npo|continue.*iv|maintain.*ngt)/i.test(transcript),
      serialExam: /(serial.*exam|monitor.*vital|serial.*assess)/i.test(transcript),
    };

    if (!dispositionChecks.admit) {
      feedback.push('Missing: Admit to General Surgery');
    }
    if (!dispositionChecks.surgery) {
      feedback.push('Missing: Surgical evaluation for possible operative intervention');
    }
    if (!dispositionChecks.npoFluidsContinue) {
      feedback.push('Missing: Continue NPO and IV fluids, maintain NGT decompression');
    }
    if (!dispositionChecks.serialExam) {
      feedback.push('Missing: Serial abdominal examinations and vital signs every 2-4 hours');
    }

    // Check for contingency planning
    const contingencyMentioned = /(if.*worsen|contingency|surgical.*intervention|if.*persist)/i.test(transcript);
    if (contingencyMentioned) {
      feedback.push('✔ Excellent job discussing contingency plan');
    }

    // Check for patient education
    const educationMentioned = /(patient.*education|explain|counsel|discuss.*patient)/i.test(transcript);
    if (educationMentioned) {
      feedback.push('✔ Good job including patient education');
    }
  }

  return {
    score: 20,
    maxScore: 20,
    feedback,
    inaccuracies,
    passed: true
  };
}

export function analyzePresentationTranscript(
  medicalCase: MedicalCase,
  transcript: string
): FeedbackResult {
  const wordCount = countWords(transcript);
  const sentenceCount = countSentences(transcript);
  const fillerInfo = detectFillerWords(transcript);

  const estimatedMinutes = wordCount / 120;
  const wordsPerMinute = Math.round(wordCount / Math.max(estimatedMinutes, 0.5));

  const stepScores = {
    frame: evaluateFrame(transcript, medicalCase, wordsPerMinute),
    context: evaluateContext(transcript),
    story: evaluateStory(transcript, medicalCase),
    pertinentFindings: evaluatePertinentFindings(transcript, medicalCase),
    background: evaluateBackground(transcript, medicalCase),
    familyHistory: evaluateFamilyHistory(transcript, medicalCase),
    objectiveData: evaluateObjectiveData(transcript, medicalCase),
    assessment: evaluateAssessment(transcript, medicalCase),
    plan: evaluatePlan(transcript, medicalCase)
  };

  const overallGrade = calculateOverallGrade(stepScores);

  const frameFeedback: SOAPFeedback = {
    score: stepScores.frame.score,
    maxScore: stepScores.frame.maxScore,
    feedback: stepScores.frame.feedback,
    passed: stepScores.frame.passed
  };

  const subjectiveFeedback: SOAPFeedback = {
    score: stepScores.context.score + stepScores.story.score + stepScores.pertinentFindings.score +
           stepScores.background.score + stepScores.familyHistory.score,
    maxScore: stepScores.context.maxScore + stepScores.story.maxScore + stepScores.pertinentFindings.maxScore +
              stepScores.background.maxScore + stepScores.familyHistory.maxScore,
    feedback: [
      ...stepScores.context.feedback,
      ...stepScores.story.feedback,
      ...stepScores.pertinentFindings.feedback,
      ...stepScores.background.feedback,
      ...stepScores.familyHistory.feedback
    ],
    passed: stepScores.context.passed && stepScores.story.passed && stepScores.pertinentFindings.passed &&
            stepScores.background.passed && stepScores.familyHistory.passed
  };

  const objectiveFeedback: SOAPFeedback = {
    score: stepScores.objectiveData.score,
    maxScore: stepScores.objectiveData.maxScore,
    feedback: stepScores.objectiveData.feedback,
    passed: stepScores.objectiveData.passed
  };

  const assessmentFeedback: SOAPFeedback = {
    score: stepScores.assessment.score,
    maxScore: stepScores.assessment.maxScore,
    feedback: stepScores.assessment.feedback,
    passed: stepScores.assessment.passed
  };

  const planFeedback: SOAPFeedback = {
    score: stepScores.plan.score,
    maxScore: stepScores.plan.maxScore,
    feedback: stepScores.plan.feedback,
    passed: stepScores.plan.passed
  };

  return {
    soapSections: {
      frame: frameFeedback,
      subjective: subjectiveFeedback,
      objective: objectiveFeedback,
      assessment: assessmentFeedback,
      plan: planFeedback
    },
    metrics: {
      wordCount,
      estimatedMinutes,
      overallGrade,
      fillerWordCount: fillerInfo.count,
      fillerWords: fillerInfo.breakdown,
      wordsPerMinute,
      excessFillerWords: fillerInfo.sentencesWithExcessFillers
    },
    annotatedTranscript: transcript,
    stepByStepScores: stepScores,
    inaccuracies: {
      frame: stepScores.frame.inaccuracies || [],
      subjective: [
        ...(stepScores.story.inaccuracies || []),
        ...(stepScores.pertinentFindings.inaccuracies || []),
        ...(stepScores.background.inaccuracies || []),
        ...(stepScores.familyHistory.inaccuracies || [])
      ],
      objective: stepScores.objectiveData.inaccuracies || [],
      assessment: stepScores.assessment.inaccuracies || [],
      plan: stepScores.plan.inaccuracies || []
    }
  };
}
