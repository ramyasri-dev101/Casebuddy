export const ARNOLD_PETERSON_CASE_ID = '1d659c15-cd53-4641-861b-e97b608b4896';

export const ARNOLD_PETERSON_REFERENCE = {
  frame: {
    patientName: 'Arnold Peterson',
    age: 65,
    sex: 'male',
    chiefComplaint: 'chest pain',
  },

  context: {
    onset: 'mild intermittent discomfort yesterday, became severe 3 hours ago during exertion (chasing dog)',
    reason: 'central, squeezing chest pain radiating to shoulders; persistent despite rest; concern for cardiac cause',
    duration: '3 hours',
  },

  hpi: {
    onset: 'yesterday, worsened acutely 3 hours ago with exertion',
    location: 'central (retrosternal) chest',
    duration: 'constant for 3 hours',
    characteristics: 'squeezing, pressure-like, non-pleuritic, non-reproducible',
    alleviating: 'none; rest provides no relief',
    aggravating: 'physical exertion (chasing dog), possibly deep inspiration',
    radiation: 'to both shoulders',
    timing: 'constant',
    severity: '7/10',
  },

  pertinentPositives: [
    'exertional onset',
    'pressure quality',
    'radiation to shoulders',
    'persistent pain',
    'hypertension',
    'transient dyspnea with exertion',
    'known reflux disease',
  ],

  pertinentNegatives: [
    'no diaphoresis',
    'no syncope',
    'no palpitations',
    'no prior MI',
    'no cough',
    'no hemoptysis',
    'no pleuritic pain',
    'no fever',
    'no orthopnea',
    'no nausea',
    'no vomiting',
    'no epigastric burning',
    'no pain on palpation or movement',
    'no lightheadedness',
    'no focal weakness',
    'no presyncope',
    'no weight loss',
    'no chills',
  ],

  pmh: [
    'hypertension (controlled on thiazide diuretic)',
    'gastroesophageal reflux disease',
    'chronic constipation',
    'cerumen impaction (right ear)',
  ],

  medications: [
    'chlorthalidone',
  ],

  allergies: 'none known',

  socialHistory: {
    smoking: '1 pack/day × 20 years (20 pack-years); considering quitting',
    alcohol: 'not specified',
    drugs: 'not reported',
  },

  familyHistory: [
    'hypertension in father and uncle',
    'thyroidectomy in mother (likely benign disease)',
    'asthma and penicillin allergy in brother',
    'no family history of premature coronary disease, PE, or dissection',
  ],

  vitals: {
    temperature: '36.5 °C',
    heartRate: '90 bpm',
    respiratoryRate: '18/min',
    bloodPressure: '150/80 mm Hg',
    spO2: '93% on room air',
  },

  physicalExam: {
    general: 'alert, oriented, no acute distress',
    heent: 'no JVD, carotid bruits, or oropharyngeal abnormalities',
    cardiovascular: 'normal S1, S2; no murmurs, rubs, or gallops',
    respiratory: 'clear breath sounds bilaterally; no crackles or wheezes',
    abdomen: 'soft, non-tender; no organomegaly',
    peripheralVascular: 'no edema, no tenderness, strong equal pulses',
    neurological: 'normal',
    integumentary: 'no rash',
  },

  labs: {
    status: 'none yet available',
  },

  imaging: {
    ecg: 'normal sinus rhythm, no ST-T abnormalities',
  },

  assessment: {
    primary: 'acute coronary syndrome (unstable angina vs. NSTEMI)',
    reasoning: [
      'exertional, pressure-like, radiating pain',
      'persistent >20 min, unrelieved by rest',
      'risk factors: male, age > 60, hypertension, smoking',
      'ECG normal (possible early or non-ST elevation pattern)',
    ],
    dangerousDifferentials: [
      'NSTEMI / Unstable Angina',
      'STEMI',
      'pulmonary embolism',
      'aortic dissection',
      'pneumothorax',
      'pericarditis',
    ],
    otherDifferentials: [
      'GERD',
      'musculoskeletal chest pain',
      'anxiety',
    ],
  },

  plan: {
    symptomatic: [
      'nitroglycerin 0.4 mg SL if SBP ≥ 100 mm Hg',
      'aspirin 325 mg chewed',
      'oxygen if SpO₂ < 94%',
      'morphine 2 mg IV if pain persists',
    ],
    labs: [
      'troponin I/T (serial)',
      'CBC',
      'BMP / electrolytes',
      'lipid panel',
      'HbA1c / glucose',
    ],
    imaging: [
      'chest X-ray',
      'echocardiogram',
      'CT angiogram (if PE or dissection suspected)',
    ],
    disposition: [
      'admit to monitored bed / telemetry',
      'serial ECGs and troponins',
      'cardiology consult',
    ],
  },
};
