export interface LabRange {
  min?: number;
  max?: number;
  unit: string;
  referenceRange?: string;
}

export const albertaLabRanges: Record<string, LabRange> = {
  WBC: { min: 4.0, max: 11.0, unit: '×10⁹/L' },
  Hemoglobin: { min: 120, max: 160, unit: 'g/L' },
  Hematocrit: { min: 0.37, max: 0.47, unit: 'L/L' },
  Platelets: { min: 150, max: 400, unit: '×10⁹/L' },
  Neutrophils: { min: 2.0, max: 7.5, unit: '×10⁹/L' },
  Lymphocytes: { min: 1.0, max: 4.0, unit: '×10⁹/L' },
  Monocytes: { min: 0.2, max: 0.8, unit: '×10⁹/L' },
  Eosinophils: { min: 0.0, max: 0.5, unit: '×10⁹/L' },
  Basophils: { min: 0.0, max: 0.2, unit: '×10⁹/L' },

  Sodium: { min: 135, max: 145, unit: 'mmol/L' },
  Potassium: { min: 3.5, max: 5.0, unit: 'mmol/L' },
  Chloride: { min: 98, max: 107, unit: 'mmol/L' },
  Bicarbonate: { min: 22, max: 29, unit: 'mmol/L' },
  CO2: { min: 22, max: 29, unit: 'mmol/L' },

  Creatinine: { min: 50, max: 120, unit: 'μmol/L' },
  Urea: { min: 2.5, max: 7.5, unit: 'mmol/L' },
  eGFR: { min: 90, unit: 'mL/min/1.73m²', referenceRange: '>90' },

  CRP: { max: 10, unit: 'mg/L', referenceRange: '<10' },
  'C-reactive protein': { max: 10, unit: 'mg/L', referenceRange: '<10' },

  'β-hCG': { unit: 'IU/L', referenceRange: '<5 (non-pregnant)' },
  'Beta-hCG': { unit: 'IU/L', referenceRange: '<5 (non-pregnant)' },

  Glucose: { min: 3.6, max: 6.0, unit: 'mmol/L' },

  WBCs: { referenceRange: '0-5', unit: 'cells/HPF' },
  RBCs: { referenceRange: '0-2', unit: 'cells/HPF' },
  Bacteria: { referenceRange: 'None', unit: '' },
  Nitrites: { referenceRange: 'Negative', unit: '' },
  Leukocyte_esterase: { referenceRange: 'Negative', unit: '' },
  'Leukocyte esterase': { referenceRange: 'Negative', unit: '' },
  Protein: { referenceRange: 'Negative', unit: '' },
  Blood: { referenceRange: 'Negative', unit: '' },
  Ketones: { referenceRange: 'Negative', unit: '' },
};

export function getLabRange(testName: string): LabRange | null {
  const normalized = testName.replace(/_/g, ' ').trim();

  for (const [key, range] of Object.entries(albertaLabRanges)) {
    if (key.toLowerCase() === normalized.toLowerCase()) {
      return range;
    }
  }

  return null;
}

export function formatReferenceRange(range: LabRange): string {
  if (range.referenceRange) {
    return `${range.referenceRange} ${range.unit}`.trim();
  }

  if (range.min !== undefined && range.max !== undefined) {
    return `${range.min}-${range.max} ${range.unit}`.trim();
  }

  if (range.min !== undefined) {
    return `>${range.min} ${range.unit}`.trim();
  }

  if (range.max !== undefined) {
    return `<${range.max} ${range.unit}`.trim();
  }

  return 'N/A';
}
