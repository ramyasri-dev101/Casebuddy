export const PETER_BROOKS_CASE_ID = 'eaba0807-c483-46a7-b51b-7d423e4d6d85';

export const PETER_BROOKS_REFERENCE = {
  frame: {
    patientName: 'Peter Brooks',
    age: 80,
    sex: 'male',
    chiefComplaint: 'abdominal pain',
  },

  context: {
    onset: 'a few days ago, coinciding with granddaughter\'s birthday',
    reason: 'progressive abdominal pain, distension, and vomiting not relieved by home measures',
    duration: 'several days',
  },

  hpi: {
    onset: 'a few days ago',
    location: 'diffuse, generalized abdominal pain',
    duration: 'several days',
    characteristics: 'cramping, deep, colicky pain with waxing and waning severity',
    alleviating: 'none identified',
    aggravating: 'likely worsened by eating or movement',
    radiation: 'none reported',
    timing: 'fluctuating, with no pain-free periods',
    severity: 'severe; "never had it this bad before"',
  },

  associatedSymptoms: [
    'nausea and recurrent vomiting',
    'constipation (no bowel movement for several days)',
    'minimal flatus',
    'abdominal distension',
  ],

  pertinentPositives: [
    'abdominal pain',
    'nausea',
    'vomiting',
    'constipation',
    'distension',
    'minimal flatus',
    'prior abdominal surgeries',
    'hypertension',
    'known abdominal aortic dilation',
    'nocturia',
    'chronic knee arthritis',
  ],

  pertinentNegatives: [
    'no blood in stool',
    'no fever',
    'no chills',
    'no recent illness',
    'no weight loss',
    'no diarrhea',
    'no GI bleeding',
    'no jaundice',
    'no chest pain',
    'no palpitations',
    'no syncope',
    'no dyspnea',
    'no cough',
    'no pleuritic pain',
    'no dysuria',
    'no hematuria',
    'no dizziness',
    'no confusion',
    'no focal deficits',
    'no new joint pain',
    'no back pain',
  ],

  pmh: [
    'hypertension',
    'abdominal aortic dilation',
    'osteoarthritis',
    'chronic constipation',
  ],

  medications: [
    'Coversyl (perindopril) 8 mg daily',
    'Lipitor (atorvastatin) 40 mg nightly',
  ],

  allergies: 'none known',

  surgicalHistory: [
    'cholecystectomy (remote; RUQ scar)',
    'ventral/abdominal hernia repair (2014)',
    'wrist fixation for fracture after fall (remote)',
  ],

  socialHistory: {
    smoking: 'never smoked',
    alcohol: 'occasional (one scotch some evenings)',
    drugs: 'none',
    living: 'resides with wife in Scenic Acres Lodge (assisted living)',
    diet: 'likely low fibre; history of constipation',
    exercise: 'mildly active; ambulatory; receives periodic knee steroid injections',
    travel: 'none recently',
  },

  familyHistory: 'adopted; family history unknown',

  vitals: {
    temperature: '36.3 °C',
    heartRate: '85 bpm',
    respiratoryRate: '18/min',
    bloodPressure: '135/73 mm Hg',
    spO2: '96% on room air',
    weight: '69 kg',
    height: '170 cm',
    bmi: '23.5 kg/m²',
    interpretation: 'vitals are stable; no fever or hypotension',
  },

  physicalExam: {
    general: 'appears well',
    cardiovascular: 'normal heart sounds. no murmur.',
    respiratory: 'normal work of breathing. normal breath sounds.',
    abdominal: 'diffusely tender abdomen. abdomen distended. hyperactive bowel sounds. 8 cm linear scar in RUQ. no hernia or masses palpated or observed. negative Murphy\'s and McBurney\'s.',
  },

  labs: {
    status: 'no laboratory results yet available',
    recommended: [
      'CBC (leukocytosis, anemia)',
      'BMP / Electrolytes (dehydration, renal function, acid-base status)',
      'Lactate (ischemia or strangulation)',
      'LFTs, Amylase, Lipase (hepatobiliary or pancreatic pathology)',
      'Coagulation Profile (preoperative readiness)',
      'Urinalysis (rule out urinary infection or hematuria)',
    ],
  },

  imaging: {
    status: 'none yet performed',
    recommended: [
      'Abdominal X-ray (upright and supine): air-fluid levels, dilated loops, gas distribution',
      'CT Abdomen and Pelvis with IV contrast: confirm obstruction, identify transition point, evaluate for ischemia, perforation, or AAA expansion',
      'Abdominal Ultrasound: evaluate aortic size and confirm presence/absence of aneurysm',
    ],
  },

  assessment: {
    primary: 'small bowel obstruction (SBO) likely secondary to postoperative adhesions',
    reasoning: [
      'history of multiple abdominal surgeries',
      'symptoms: vomiting, constipation, abdominal distension, minimal flatus',
      'exam: diffuse tenderness, hyperactive bowel sounds, distension',
      'stable vitals with no peritonitis',
      'pathophysiology: adhesions cause partial or complete obstruction → bowel distension → fluid accumulation → vomiting, pain, and risk of ischemia if strangulated',
    ],
    dangerousDifferentials: [
      'strangulated small bowel obstruction',
      'bowel ischemia',
      'ruptured or expanding abdominal aortic aneurysm',
      'perforated viscus',
    ],
    otherDifferentials: [
      'large bowel obstruction (LBO)',
      'paralytic ileus',
      'gallstone ileus',
      'mesenteric ischemia',
      'diverticulitis',
      'colorectal malignancy',
      'severe constipation / fecal impaction',
    ],
  },

  plan: {
    symptomatic: [
      'keep NPO (nil per os) to prevent worsening distension',
      'start IV fluids (Normal Saline or Ringer\'s Lactate) for rehydration and correction of electrolyte loss',
      'insert nasogastric tube (NGT) for gastric decompression and relief of vomiting',
      'provide pain control with acetaminophen; use opioids cautiously if severe pain (may reduce motility)',
      'administer antiemetics (e.g., ondansetron 4 mg IV PRN)',
    ],
    labs: [
      'CBC: look for leukocytosis (infection, ischemia) and anemia',
      'BMP / Electrolytes: assess dehydration, renal function, acid-base status',
      'Lactate: elevated levels suggest ischemia or strangulation',
      'LFTs, Amylase, Lipase: rule out hepatobiliary or pancreatic pathology',
      'Coagulation Profile: preoperative readiness',
      'Urinalysis: rule out urinary infection or hematuria (if AAA suspected)',
    ],
    imaging: [
      'Abdominal X-ray (upright and supine): identify air-fluid levels, dilated loops, and gas distribution',
      'CT Abdomen and Pelvis with IV contrast: confirm obstruction, identify transition point, evaluate for ischemia, perforation, or AAA expansion',
      'Abdominal Ultrasound: evaluate aortic size and confirm presence/absence of aneurysm',
    ],
    disposition: [
      'admit to General Surgery',
      'continue NPO and IV fluids',
      'maintain NGT decompression',
      'serial abdominal examinations and vital signs every 2–4 hours',
      'surgical evaluation for possible operative intervention',
    ],
    contingency: [
      'if pain intensifies, vitals deteriorate, or peritoneal signs develop → urgent CT and surgical exploration',
      'if NGT output remains high or obstruction persists beyond 48–72 hours → surgical intervention',
      'if obstruction resolves → gradually reintroduce fluids and advance diet cautiously',
    ],
    patientEducation: [
      'explain: "You likely have a bowel blockage, probably due to scar tissue from previous surgeries"',
      'discuss: expected management (IV fluids, NGT, hospital stay, possible surgery)',
      'review red flags: increasing pain, vomiting, fever, abdominal swelling, or lightheadedness',
      'emphasize hydration, dietary fibre, and stool regularity post-recovery',
      'counsel on medication adherence for hypertension and lipid control',
      'recommend follow-up for abdominal aortic dilation surveillance and surgical review after discharge',
    ],
  },
};
