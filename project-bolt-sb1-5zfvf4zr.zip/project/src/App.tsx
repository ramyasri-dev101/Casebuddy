import { useState, useEffect, useRef } from 'react';
import { supabase, MedicalCase } from './lib/supabase';
import { CaseDisplay } from './components/CaseDisplay';
import { RecordingInterface, RecordingInterfaceRef } from './components/RecordingInterface';
import { FeedbackDisplay } from './components/FeedbackDisplay';
import { analyzePresentationTranscript, FeedbackResult } from './utils/feedbackAnalysis';
import { NeuronLogo } from './components/NeuronLogo';
import { RotateCcw, Home, ArrowLeft, Info, ChevronDown } from 'lucide-react';

type AppState = 'idle' | 'case-loaded' | 'recording' | 'feedback';

function App() {
  const [state, setState] = useState<AppState>('idle');
  const [currentCase, setCurrentCase] = useState<MedicalCase | null>(null);
  const [transcript, setTranscript] = useState<string>('');
  const [feedback, setFeedback] = useState<FeedbackResult | null>(null);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [loading, setLoading] = useState(false);
  const [showGuidelines, setShowGuidelines] = useState(false);
  const [showPresentations, setShowPresentations] = useState(false);
  const [processingTranscript, setProcessingTranscript] = useState(false);
  const recordingControlRef = useRef<RecordingInterfaceRef>(null);
  const presentationsRef = useRef<HTMLDivElement>(null);

  // Scroll to top when state changes to feedback
  useEffect(() => {
    if (state === 'feedback') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [state]);

  // Close presentations dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (presentationsRef.current && !presentationsRef.current.contains(event.target as Node)) {
        setShowPresentations(false);
      }
    };

    if (showPresentations) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showPresentations]);

  const loadNewCase = async () => {
    setLoading(true);

    // Reset recording interface if it exists
    if (recordingControlRef.current) {
      recordingControlRef.current.reset();
    }

    // Reset all state to ensure clean slate
    setTranscript('');
    setFeedback(null);
    setAudioBlob(null);
    setShowGuidelines(false);
    setShowPresentations(false);
    setProcessingTranscript(false);

    try {
      const { data, error } = await supabase
        .from('medical_cases')
        .select('*');

      if (error) throw error;

      if (data && data.length > 0) {
        const randomCase = data[Math.floor(Math.random() * data.length)];
        setCurrentCase(randomCase);
        setState('case-loaded');
      }
    } catch (error) {
      console.error('Error loading case:', error);
      alert('Failed to load case. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const loadSpecificCase = async (caseId: string) => {
    setLoading(true);

    // Close presentations dropdown
    setShowPresentations(false);

    // Reset recording interface if it exists
    if (recordingControlRef.current) {
      recordingControlRef.current.reset();
    }

    // Reset all state to ensure clean slate
    setTranscript('');
    setFeedback(null);
    setAudioBlob(null);
    setShowGuidelines(false);
    setProcessingTranscript(false);

    try {
      const { data, error } = await supabase
        .from('medical_cases')
        .select('*')
        .eq('id', caseId)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        setCurrentCase(data);
        setState('case-loaded');
      }
    } catch (error) {
      console.error('Error loading case:', error);
      alert('Failed to load case. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleTranscriptReady = async (transcriptText: string, audio: Blob | null) => {
    if (!currentCase) return;

    setProcessingTranscript(true);
    setTranscript(transcriptText);
    setAudioBlob(audio);
    const analysis = analyzePresentationTranscript(currentCase, transcriptText);

    setFeedback(analysis);
    setState('feedback');
    setProcessingTranscript(false);
  };

  const resetToStart = () => {
    setState('idle');
    setCurrentCase(null);
    setTranscript('');
    setFeedback(null);
    setAudioBlob(null);
  };

  const goBack = () => {
    if (state === 'feedback') {
      setState('case-loaded');
      setFeedback(null);
    } else if (state === 'case-loaded') {
      setState('idle');
      setCurrentCase(null);
    }
  };


  return (
    <div className="min-h-screen bg-[#DAF1DE]">
      <header className="backdrop-blur-xl bg-[#DAF1DE]/60 border-b border-black/[0.06] sticky top-0 z-40">
        <div className="max-w-[980px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 sm:h-20">
            <div className="flex items-center gap-2">
              {state !== 'idle' && (
                <button
                  onClick={resetToStart}
                  className="flex items-center justify-center hover:opacity-70 transition-smooth"
                  aria-label="Go to home"
                >
                  <Home className="w-5 h-5 sm:w-6 sm:h-6 text-[#0B2B26] stroke-2" />
                </button>
              )}
              <h1 className="text-lg sm:text-xl font-semibold tracking-tight text-[#0B2B26]">CaseBuddy</h1>
              {state !== 'idle' && (
                <button
                  onClick={goBack}
                  className="flex items-center justify-center hover:opacity-70 transition-smooth"
                  aria-label="Go back"
                >
                  <ArrowLeft className="w-5 h-5 sm:w-6 sm:h-6 text-[#0B2B26] stroke-2" />
                </button>
              )}
            </div>

            {state !== 'idle' && (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowGuidelines(true)}
                  className="flex items-center justify-center p-2 sm:p-3 rounded-full bg-[#0B2B26] hover:bg-[#0B2B26]/90 transition-smooth text-white"
                  aria-label="Recording guidelines"
                >
                  <Info className="w-4 h-4 sm:w-5 sm:h-5" />
                </button>
                <button
                  onClick={loadNewCase}
                  disabled={loading}
                  className="flex items-center gap-1.5 sm:gap-2 px-4 sm:px-5 py-2 sm:py-3 rounded-full bg-[#0B2B26] hover:bg-[#0B2B26]/90 transition-smooth text-xs sm:text-sm font-medium text-white disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <RotateCcw className="w-4 h-4 sm:w-5 sm:h-5" />
                  <span className="whitespace-nowrap">New Case</span>
                </button>
                <div className="relative" ref={presentationsRef}>
                  <button
                    onClick={() => setShowPresentations(!showPresentations)}
                    disabled={loading}
                    className="flex items-center gap-1.5 sm:gap-2 px-4 sm:px-5 py-2 sm:py-3 rounded-full bg-[#0B2B26] hover:bg-[#0B2B26]/90 transition-smooth text-xs sm:text-sm font-medium text-white disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <span className="whitespace-nowrap">Presentations</span>
                    <ChevronDown className="w-4 h-4 sm:w-5 sm:h-5" />
                  </button>
                  {showPresentations && (
                    <div className="absolute right-0 mt-2 z-50 flex flex-col gap-2">
                      <button
                        onClick={() => loadSpecificCase('eaba0807-c483-46a7-b51b-7d423e4d6d85')}
                        disabled={loading}
                        className="flex items-center gap-1.5 sm:gap-2 px-4 sm:px-5 py-2 sm:py-3 rounded-full bg-[#DAF1DE] border-2 border-[#0B2B26] hover:bg-[#c5e6ca] transition-smooth text-xs sm:text-sm font-medium text-[#0B2B26] shadow-lg whitespace-nowrap disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <span>Abdominal Pain</span>
                      </button>
                      <button
                        onClick={() => loadSpecificCase('1d659c15-cd53-4641-861b-e97b608b4896')}
                        disabled={loading}
                        className="flex items-center gap-1.5 sm:gap-2 px-4 sm:px-5 py-2 sm:py-3 rounded-full bg-[#DAF1DE] border-2 border-[#0B2B26] hover:bg-[#c5e6ca] transition-smooth text-xs sm:text-sm font-medium text-[#0B2B26] shadow-lg whitespace-nowrap disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <span>Chest Pain</span>
                      </button>
                      <button
                        onClick={() => loadSpecificCase('fbe00c74-6bda-45bc-8acd-0338ba19d91d')}
                        disabled={loading}
                        className="flex items-center gap-1.5 sm:gap-2 px-4 sm:px-5 py-2 sm:py-3 rounded-full bg-[#DAF1DE] border-2 border-[#0B2B26] hover:bg-[#c5e6ca] transition-smooth text-xs sm:text-sm font-medium text-[#0B2B26] shadow-lg whitespace-nowrap disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <span>Dyspnea</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-[980px] mx-auto px-4 sm:px-6 lg:px-8">
        {state === 'idle' && (
          <div className="text-center py-12 sm:py-16 lg:py-24">
            <h2 className="text-3xl sm:text-4xl lg:text-6xl font-semibold text-black mb-4 sm:mb-6 tracking-tight leading-tight px-4">
              Practice medical case<br className="hidden sm:block" />
              <span className="sm:hidden"> </span>presentations.
            </h2>
            <p className="text-black/75 mb-8 sm:mb-12 text-base sm:text-lg lg:text-xl leading-relaxed max-w-2xl mx-auto px-4">
              Review realistic patient encounters, record your presentation, and receive detailed feedback.
            </p>
            <button
              onClick={loadNewCase}
              disabled={loading}
              className="px-6 sm:px-8 py-2.5 sm:py-3 bg-[#0B2B26] text-white text-sm sm:text-base font-medium rounded-full hover:bg-[#0B2B26]/90 transition-smooth disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Loading...' : 'Get started'}
            </button>
          </div>
        )}


        {state === 'case-loaded' && currentCase && (
          <div className="space-y-4 sm:space-y-6 lg:space-y-8 py-6 sm:py-8 lg:py-12">
            <CaseDisplay
              medicalCase={currentCase}
              recordingControls={
                <RecordingInterface
                  ref={recordingControlRef}
                  onTranscriptReady={handleTranscriptReady}
                  renderControlsOnly={true}
                  showGuidelines={showGuidelines}
                  onCloseGuidelines={() => setShowGuidelines(false)}
                  isProcessing={processingTranscript}
                />
              }
            />
          </div>
        )}

        {state === 'feedback' && currentCase && feedback && (
          <div className="space-y-4 sm:space-y-6 lg:space-y-8 py-6 sm:py-8 lg:py-12">
            <FeedbackDisplay transcript={transcript} feedback={feedback} medicalCase={currentCase} audioBlob={audioBlob} />
          </div>
        )}
      </main>

      <footer className="max-w-[980px] mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 lg:py-16 text-center">
        <p className="text-sm sm:text-base lg:text-lg text-black font-medium">CaseBuddy is a training tool for medical students. No data is stored between sessions.</p>
      </footer>
    </div>
  );
}

export default App;
