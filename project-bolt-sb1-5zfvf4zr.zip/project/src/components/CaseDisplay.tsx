import { MedicalCase } from '../lib/supabase';
import { Activity, Volume2, Hand, ChevronUp, ChevronDown, FileText } from 'lucide-react';
import { useState, ReactNode, useEffect, useRef } from 'react';

interface CaseDisplayProps {
  medicalCase: MedicalCase;
  recordingControls?: ReactNode;
}

export function CaseDisplay({ medicalCase, recordingControls }: CaseDisplayProps) {
  const [activeTab, setActiveTab] = useState<'conversation' | 'physical' | 'investigations'>('conversation');
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [currentLineIndex, setCurrentLineIndex] = useState(0);
  const [playbackRate, setPlaybackRate] = useState(1.0);
  const isPausedRef = useRef(false);
  const playbackRateRef = useRef(1.0);
  const lines = medicalCase.conversation.split('\n').filter(line => line.trim());
  const currentUtteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  useEffect(() => {
    playbackRateRef.current = playbackRate;
  }, [playbackRate]);

  useEffect(() => {
    return () => {
      // Cleanup speech synthesis on unmount
      speechSynthesis.cancel();
    };
  }, []);

  // Parse vital signs from the exam_vitals (can be JSON object or string)
  const parseVitalSigns = (vitalsData: any) => {
    const vitals = {
      bp: '',
      hr: '',
      rr: '',
      temperature: '',
      o2_saturation: '',
      weight: '',
      height: '',
      bmi: ''
    };

    if (!vitalsData) return vitals;

    console.log('Raw vitalsData:', vitalsData, 'Type:', typeof vitalsData);

    // Parse the data if it's a string
    let parsedData = vitalsData;
    if (typeof vitalsData === 'string') {
      try {
        parsedData = JSON.parse(vitalsData);
        console.log('Parsed once:', parsedData, 'Type:', typeof parsedData);
      } catch (e) {
        console.log('Parse error:', e);
      }
    }

    // If it's a JSON object, extract values directly
    if (typeof parsedData === 'object' && parsedData !== null) {
      vitals.bp = parsedData['Blood pressure'] || parsedData.bp || '';
      vitals.hr = parsedData['Heart rate'] || parsedData.hr || '';
      vitals.rr = parsedData['Respiratory rate'] || parsedData.rr || '';
      vitals.temperature = parsedData['Temperature'] || parsedData.temperature || '';
      vitals.o2_saturation = parsedData['SpO₂'] || parsedData.o2_saturation || '';
      vitals.weight = parsedData['Weight'] || parsedData.weight || '';
      vitals.height = parsedData['Height'] || parsedData.height || '';
      vitals.bmi = parsedData['BMI'] || parsedData.bmi || '';

      console.log('Extracted vitals:', vitals);
      return vitals;
    }

    // Otherwise, parse as text string
    const vitalsText = String(vitalsData);

    // Extract BP (various formats) - look for patterns like "120/80" with optional text before
    const bpMatch = vitalsText.match(/(\d{2,3}\/\d{2,3})/i);
    if (bpMatch) vitals.bp = bpMatch[1];

    // Extract HR - look for 2-3 digit numbers near "HR" or "Heart Rate" or "bpm"
    const hrMatch = vitalsText.match(/(?:HR|Heart\s*Rate|Pulse)[:\s]*(\d{2,3})(?:\s*bpm)?/i) ||
                    vitalsText.match(/(\d{2,3})\s*bpm/i);
    if (hrMatch) vitals.hr = hrMatch[1];

    // Extract RR
    const rrMatch = vitalsText.match(/(?:RR|Respiratory\s*Rate|Resp)[:\s]*(\d{1,2})(?:\s*(?:breaths?\/min|rpm))?/i);
    if (rrMatch) vitals.rr = rrMatch[1];

    // Extract Temperature
    const tempMatch = vitalsText.match(/(?:Temp(?:erature)?)[:\s]*([\d.]+)\s*°?[CF]?/i) ||
                      vitalsText.match(/([\d.]+)\s*°[CF]/i);
    if (tempMatch) vitals.temperature = tempMatch[1];

    // Extract O2 Saturation
    const o2Match = vitalsText.match(/(?:O2|SpO2|Oxygen\s*Sat(?:uration)?)[:\s]*([\d.]+)\s*%?/i) ||
                    vitalsText.match(/([\d]{2,3})\s*%/i);
    if (o2Match) vitals.o2_saturation = o2Match[1];

    // Extract Weight
    const weightMatch = vitalsText.match(/(?:Weight)[:\s]*([\d.]+)\s*(?:kg|lbs?)?/i);
    if (weightMatch) vitals.weight = weightMatch[1];

    // Extract Height
    const heightMatch = vitalsText.match(/(?:Height)[:\s]*([\d.]+)\s*(?:cm|m)?/i);
    if (heightMatch) vitals.height = heightMatch[1];

    // Extract BMI
    const bmiMatch = vitalsText.match(/(?:BMI)[:\s]*([\d.]+)/i);
    if (bmiMatch) vitals.bmi = bmiMatch[1];

    return vitals;
  };

  const vitalSigns = parseVitalSigns(medicalCase.exam_vitals);

  const getVoiceForGender = (isFemale: boolean): 'alloy' | 'echo' | 'fable' | 'onyx' | 'nova' | 'shimmer' => {
    if (isFemale) {
      return 'nova';
    } else {
      return 'echo';
    }
  };

  const playConversation = async () => {
    // If resuming from pause, continue from current line
    if (isPaused) {
      setIsPaused(false);
      isPausedRef.current = false;
      setIsPlaying(true);
      await speakFromIndex(currentLineIndex);
      return;
    }

    // Starting fresh
    setIsPlaying(true);
    setIsPaused(false);
    isPausedRef.current = false;
    setCurrentLineIndex(0);
    await speakFromIndex(0);
  };

  const speakFromIndex = async (startIndex: number) => {
    let currentIndex = startIndex;

    const speakNext = async () => {
      // Check if we've been paused
      if (isPausedRef.current) {
        return;
      }

      if (currentIndex >= lines.length) {
        setIsPlaying(false);
        setIsPaused(false);
        isPausedRef.current = false;
        setCurrentLineIndex(0);
        return;
      }

      const line = lines[currentIndex];
      const isStudent = line.startsWith('Student:');
      const isMedicalStudent = line.startsWith('Medical Student:');
      const isProvider = line.startsWith('Provider:') || line.startsWith('Physician:');

      let text = '';
      if (isStudent) {
        text = line.replace(/^Student:\s*/, '');
      } else if (isMedicalStudent) {
        text = line.replace(/^Medical Student:\s*/, '');
      } else if (isProvider) {
        text = line.replace(/^(Provider:|Physician:)\s*/, '');
      } else {
        text = line.replace(/^Patient:\s*/, '');
      }

      if (text.trim()) {
        const gender = (isStudent || isMedicalStudent)
          ? 'male'
          : medicalCase.patient_sex || 'male';

        const isFemale = gender.toLowerCase().includes('female');
        const voice = getVoiceForGender(isFemale);

        console.log(`Line ${currentIndex + 1}: ${(isStudent || isMedicalStudent) ? 'Student' : 'Patient'} - Gender: ${gender} - Voice: ${voice} - isFemale: ${isFemale}`);

        try {
          // Generate speech using Web Speech API
          const utterance = new SpeechSynthesisUtterance(text);
          currentUtteranceRef.current = utterance;

          const voices = speechSynthesis.getVoices();
          const englishVoices = voices.filter(v => v.lang.startsWith('en'));

          if (englishVoices.length > 0) {
            utterance.voice = englishVoices[0];
          }

          utterance.rate = playbackRateRef.current;
          utterance.pitch = isFemale ? 1.05 : 0.85;
          utterance.volume = 1.0;

          await new Promise<void>((resolve, reject) => {
            utterance.onend = () => {
              currentUtteranceRef.current = null;
              resolve();
            };
            utterance.onerror = (error) => {
              currentUtteranceRef.current = null;
              reject(error);
            };
            speechSynthesis.speak(utterance);
          });

          // Check if paused after speaking
          if (isPausedRef.current) {
            return;
          }

          currentIndex++;
          setCurrentLineIndex(currentIndex);

          // Check again if paused before continuing
          if (!isPausedRef.current) {
            setTimeout(() => {
              speakNext();
            }, 500);
          }
        } catch (error) {
          console.error('Error generating speech:', error);
          currentIndex++;
          setCurrentLineIndex(currentIndex);
          if (!isPausedRef.current) {
            speakNext();
          }
        }
      } else {
        currentIndex++;
        setCurrentLineIndex(currentIndex);
        if (!isPausedRef.current) {
          speakNext();
        }
      }
    };

    await speakNext();
  };

  const stopAudio = () => {
    // Set the ref first so callbacks check the right value immediately
    isPausedRef.current = true;
    setIsPaused(true);
    setIsPlaying(false);

    // Cancel speech synthesis
    speechSynthesis.cancel();
  };

  return (
    <div className="glass rounded-3xl overflow-hidden border-2 border-[#0B2B26]">
      <div className="p-4 sm:p-6 lg:p-8 pb-0 border-b border-black/[0.06]">
        <div className="mb-4 sm:mb-6 lg:mb-8 flex justify-between items-start gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <h2 className="text-xl sm:text-2xl lg:text-3xl font-semibold tracking-tight text-black">{medicalCase.patient_name || medicalCase.title}</h2>
            </div>
            <div className="text-black/80 text-sm sm:text-base font-light mt-1 space-y-0.5">
              {medicalCase.patient_age && (
                <div>{medicalCase.patient_age} years old</div>
              )}
              {medicalCase.patient_birthdate && (
                <div>Birthdate: {(() => {
                  const date = new Date(medicalCase.patient_birthdate);
                  const month = date.toLocaleString('en-US', { month: 'long' });
                  const day = date.getDate();
                  const year = date.getFullYear();
                  return `${month} ${day}, ${year}`;
                })()}</div>
              )}
              {medicalCase.patient_sex && (
                <div>Biological Sex: {medicalCase.patient_sex}</div>
              )}
              {medicalCase.patient_gender && (
                <div>Pronouns: {medicalCase.patient_gender}</div>
              )}
            </div>
            <div className="flex flex-wrap gap-2 mt-3 items-center">
              <button
                onClick={playConversation}
                disabled={isPlaying && !isPaused}
                className="flex items-center justify-center p-2 sm:p-3 rounded-full transition-smooth text-white border-none disabled:cursor-not-allowed disabled:opacity-50 bg-[#0B2B26] hover:bg-[#0B2B26]/90"
              >
                <Volume2 className="w-4 h-4 sm:w-5 sm:h-5" />
              </button>
              <button
                onClick={stopAudio}
                disabled={!isPlaying}
                className="flex items-center justify-center p-2 sm:p-3 rounded-full transition-smooth text-white border-none disabled:cursor-not-allowed disabled:opacity-50 bg-[#0B2B26] hover:bg-[#0B2B26]/90"
              >
                <Hand className="w-4 h-4 sm:w-5 sm:h-5" />
              </button>
              <button
                onClick={() => setPlaybackRate(Math.max(0.5, playbackRate - 0.25))}
                className="flex items-center justify-center p-2 sm:p-3 rounded-full transition-smooth text-white border-none bg-[#0B2B26] hover:bg-[#0B2B26]/90"
                aria-label="Decrease speed"
              >
                <ChevronDown className="w-4 h-4 sm:w-5 sm:h-5" />
              </button>
              <button
                onClick={() => setPlaybackRate(Math.min(2.0, playbackRate + 0.25))}
                className="flex items-center justify-center p-2 sm:p-3 rounded-full transition-smooth text-white border-none bg-[#0B2B26] hover:bg-[#0B2B26]/90"
                aria-label="Increase speed"
              >
                <ChevronUp className="w-4 h-4 sm:w-5 sm:h-5" />
              </button>
            </div>
          </div>
          {recordingControls && (
            <div className="flex-shrink-0">
              {recordingControls}
            </div>
          )}
        </div>

        <div className="flex gap-1 sm:gap-2 border-b border-black/[0.06] overflow-x-auto">
          <button
            onClick={() => setActiveTab('conversation')}
            className={`flex items-center gap-1 sm:gap-2 px-3 sm:px-4 lg:px-5 py-2 sm:py-3 text-xs sm:text-sm font-medium transition-smooth whitespace-nowrap ${
              activeTab === 'conversation'
                ? 'text-black border-b-2 border-black'
                : 'text-black/70 hover:text-black'
            }`}
          >
            Interview
          </button>
          <button
            onClick={() => setActiveTab('physical')}
            className={`flex items-center gap-1 sm:gap-2 px-3 sm:px-4 lg:px-5 py-2 sm:py-3 text-xs sm:text-sm font-medium transition-smooth whitespace-nowrap ${
              activeTab === 'physical'
                ? 'text-black border-b-2 border-black'
                : 'text-black/70 hover:text-black'
            }`}
          >
            <Activity className="w-3 h-3 sm:w-4 sm:h-4" />
            Physical Exam
          </button>
          <button
            onClick={() => setActiveTab('investigations')}
            className={`flex items-center gap-1 sm:gap-2 px-3 sm:px-4 lg:px-5 py-2 sm:py-3 text-xs sm:text-sm font-medium transition-smooth whitespace-nowrap ${
              activeTab === 'investigations'
                ? 'text-black border-b-2 border-black'
                : 'text-black/70 hover:text-black'
            }`}
          >
            <FileText className="w-3 h-3 sm:w-4 sm:h-4" />
            Investigations
          </button>
        </div>
      </div>

      <div className="p-4 sm:p-6 lg:p-8">
        {activeTab === 'conversation' && (
          <div className="bg-[#DAF1DE] rounded-2xl p-4 sm:p-6 max-h-[400px] sm:max-h-[500px] overflow-y-auto border border-[#0B2B26]">
            <div className="space-y-4">
              {lines.map((line, index) => {
                const isStudent = line.startsWith('Student:');
                const isMedicalStudent = line.startsWith('Medical Student:');
                const isProvider = line.startsWith('Provider:') || line.startsWith('Physician:');
                const isPatient = line.startsWith('Patient:');
                const isNarrator = line.startsWith('Narrator:');
                const isNurse = line.startsWith('Nurse:');

                let speaker = '';
                let text = '';

                if (isStudent) {
                  speaker = 'Student:';
                  text = line.replace(/^Student:\s*/, '');
                } else if (isMedicalStudent) {
                  speaker = 'Medical Student:';
                  text = line.replace(/^Medical Student:\s*/, '');
                } else if (isProvider) {
                  speaker = 'Physician:';
                  text = line.replace(/^(Provider:|Physician:)\s*/, '');
                } else if (isPatient) {
                  speaker = 'Patient:';
                  text = line.replace(/^Patient:\s*/, '');
                } else if (isNarrator) {
                  speaker = 'Narrator:';
                  text = line.replace(/^Narrator:\s*/, '');
                } else if (isNurse) {
                  speaker = 'Nurse:';
                  text = line.replace(/^Nurse:\s*/, '');
                } else {
                  text = line;
                }

                return (
                  <div key={index} className="flex gap-4">
                    <div className="text-sm sm:text-base text-black/80 min-w-32 flex-shrink-0 font-bold">
                      {speaker}
                    </div>
                    <div className="text-sm sm:text-base text-black/80 flex-1 leading-relaxed">{text}</div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {activeTab === 'physical' && (
          <div className="space-y-4">
            {medicalCase.exam_vitals && (
              <div className="bg-[#DAF1DE] p-4 sm:p-6 rounded-2xl border border-[#0B2B26]">
                <h4 className="font-medium text-black mb-3 sm:mb-4 text-sm sm:text-base">Vital Signs</h4>
                {(vitalSigns.bp || vitalSigns.hr || vitalSigns.rr || vitalSigns.temperature ||
                  vitalSigns.o2_saturation || vitalSigns.weight || vitalSigns.height || vitalSigns.bmi) ? (
                  <div className="space-y-2">
                    {vitalSigns.temperature && (
                      <div className="flex items-center">
                        <span className="text-black/75 font-light w-28 sm:w-36 text-sm sm:text-base">Temp:</span>
                        <span className="text-black font-light text-sm sm:text-base">{vitalSigns.temperature}</span>
                      </div>
                    )}
                    {vitalSigns.hr && (
                      <div className="flex items-center">
                        <span className="text-black/75 font-light w-28 sm:w-36 text-sm sm:text-base">HR:</span>
                        <span className="text-black font-light text-sm sm:text-base">{vitalSigns.hr}</span>
                      </div>
                    )}
                    {vitalSigns.rr && (
                      <div className="flex items-center">
                        <span className="text-black/75 font-light w-28 sm:w-36 text-sm sm:text-base">RR:</span>
                        <span className="text-black font-light text-sm sm:text-base">{vitalSigns.rr}</span>
                      </div>
                    )}
                    {vitalSigns.bp && (
                      <div className="flex items-center">
                        <span className="text-black/75 font-light w-28 sm:w-36 text-sm sm:text-base">BP:</span>
                        <span className="text-black font-light text-sm sm:text-base">{vitalSigns.bp}</span>
                      </div>
                    )}
                    {vitalSigns.o2_saturation && (
                      <div className="flex items-center">
                        <span className="text-black/75 font-light w-28 sm:w-36 text-sm sm:text-base">SpO₂:</span>
                        <span className="text-black font-light text-sm sm:text-base">{vitalSigns.o2_saturation}</span>
                      </div>
                    )}
                    {vitalSigns.weight && (
                      <div className="flex items-center">
                        <span className="text-black/75 font-light w-28 sm:w-36 text-sm sm:text-base">Weight:</span>
                        <span className="text-black font-light text-sm sm:text-base">{vitalSigns.weight}</span>
                      </div>
                    )}
                    {vitalSigns.height && (
                      <div className="flex items-center">
                        <span className="text-black/75 font-light w-28 sm:w-36 text-sm sm:text-base">Height:</span>
                        <span className="text-black font-light text-sm sm:text-base">{vitalSigns.height}</span>
                      </div>
                    )}
                    {vitalSigns.bmi && (
                      <div className="flex items-center">
                        <span className="text-black/75 font-light w-28 sm:w-36 text-sm sm:text-base">BMI:</span>
                        <span className="text-black font-light text-sm sm:text-base">{vitalSigns.bmi}</span>
                      </div>
                    )}
                  </div>
                ) : (
                  <p className="text-black/85 leading-relaxed">{medicalCase.exam_vitals}</p>
                )}
              </div>
            )}

            {medicalCase.exam_general_appearance && (
              <div className="bg-[#DAF1DE] p-4 sm:p-6 rounded-2xl border border-[#0B2B26]">
                <h4 className="font-medium text-black mb-3 text-sm sm:text-base">General Appearance</h4>
                <p className="text-sm sm:text-base text-black/85 leading-relaxed">{medicalCase.exam_general_appearance}</p>
              </div>
            )}

            {medicalCase.exam_cardiovascular && (
              <div className="bg-[#DAF1DE] p-4 sm:p-6 rounded-2xl border border-[#0B2B26]">
                <h4 className="font-medium text-black mb-3 text-sm sm:text-base">Cardiovascular</h4>
                <p className="text-sm sm:text-base text-black/85 leading-relaxed">{medicalCase.exam_cardiovascular}</p>
              </div>
            )}

            {medicalCase.exam_respiratory && (
              <div className="bg-[#DAF1DE] p-4 sm:p-6 rounded-2xl border border-[#0B2B26]">
                <h4 className="font-medium text-black mb-3 text-sm sm:text-base">Respiratory</h4>
                <p className="text-sm sm:text-base text-black/85 leading-relaxed">{medicalCase.exam_respiratory}</p>
              </div>
            )}

            {medicalCase.exam_abdominal && (
              <div className="bg-[#DAF1DE] p-4 sm:p-6 rounded-2xl border border-[#0B2B26]">
                <h4 className="font-medium text-black mb-3 text-sm sm:text-base">Abdominal</h4>
                <p className="text-sm sm:text-base text-black/85 leading-relaxed">{medicalCase.exam_abdominal}</p>
              </div>
            )}

            {medicalCase.exam_heent && (
              <div className="bg-[#DAF1DE] p-4 sm:p-6 rounded-2xl border border-[#0B2B26]">
                <h4 className="font-medium text-black mb-3 text-sm sm:text-base">HEENT</h4>
                <p className="text-sm sm:text-base text-black/85 leading-relaxed">{medicalCase.exam_heent}</p>
              </div>
            )}

            {medicalCase.exam_musculoskeletal && (
              <div className="bg-[#DAF1DE] p-4 sm:p-6 rounded-2xl border border-[#0B2B26]">
                <h4 className="font-medium text-black mb-3 text-sm sm:text-base">Musculoskeletal</h4>
                <p className="text-sm sm:text-base text-black/85 leading-relaxed">{medicalCase.exam_musculoskeletal}</p>
              </div>
            )}

            {medicalCase.exam_neurological && (
              <div className="bg-[#DAF1DE] p-4 sm:p-6 rounded-2xl border border-[#0B2B26]">
                <h4 className="font-medium text-black mb-3 text-sm sm:text-base">Neurological</h4>
                <p className="text-sm sm:text-base text-black/85 leading-relaxed">{medicalCase.exam_neurological}</p>
              </div>
            )}

            {medicalCase.exam_skin && (
              <div className="bg-[#DAF1DE] p-4 sm:p-6 rounded-2xl border border-[#0B2B26]">
                <h4 className="font-medium text-black mb-3 text-sm sm:text-base">Integumentary</h4>
                <p className="text-sm sm:text-base text-black/85 leading-relaxed">{medicalCase.exam_skin}</p>
              </div>
            )}

            {medicalCase.exam_genitourinary && (
              <div className="bg-[#DAF1DE] p-4 sm:p-6 rounded-2xl border border-[#0B2B26]">
                <h4 className="font-medium text-black mb-3 text-sm sm:text-base">Genitourinary</h4>
                <p className="text-sm sm:text-base text-black/85 leading-relaxed">{medicalCase.exam_genitourinary}</p>
              </div>
            )}

            {medicalCase.exam_peripheral_vascular && (
              <div className="bg-[#DAF1DE] p-4 sm:p-6 rounded-2xl border border-[#0B2B26]">
                <h4 className="font-medium text-black mb-3 text-sm sm:text-base">Peripheral Vascular</h4>
                <p className="text-sm sm:text-base text-black/85 leading-relaxed">{medicalCase.exam_peripheral_vascular}</p>
              </div>
            )}

            {medicalCase.exam_psychiatric && (
              <div className="bg-[#DAF1DE] p-4 sm:p-6 rounded-2xl border border-[#0B2B26]">
                <h4 className="font-medium text-black mb-3 text-sm sm:text-base">Psychiatric</h4>
                <p className="text-sm sm:text-base text-black/85 leading-relaxed">{medicalCase.exam_psychiatric}</p>
              </div>
            )}
          </div>
        )}

        {activeTab === 'investigations' && (
          <div className="space-y-4">
            {medicalCase.ecg && (
              <div className="bg-[#DAF1DE] p-4 sm:p-6 rounded-2xl border border-[#0B2B26]">
                <h4 className="font-medium text-black mb-3 text-base">ECG</h4>
                <p className="text-black/85 leading-relaxed">{medicalCase.ecg}</p>
              </div>
            )}

            {!medicalCase.ecg && (
              <div className="bg-[#DAF1DE] p-4 sm:p-6 rounded-2xl border border-[#0B2B26]">
                <p className="text-sm sm:text-base text-black/85 text-center">No investigations available</p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
