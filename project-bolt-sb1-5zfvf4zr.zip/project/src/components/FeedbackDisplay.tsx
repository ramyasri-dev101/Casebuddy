import { FeedbackResult } from '../utils/feedbackAnalysis';
import { Award, Clock, Filter, FileText, AlertCircle, Volume2, Sparkles, CheckCircle, AlertTriangle } from 'lucide-react';
import { MedicalCase } from '../lib/supabase';
import { useState, useEffect, useRef } from 'react';
import { CaseDisplay } from './CaseDisplay';

interface FeedbackDisplayProps {
  transcript: string;
  feedback: FeedbackResult;
  medicalCase: MedicalCase;
  audioBlob: Blob | null;
}

export function FeedbackDisplay({ transcript, feedback, medicalCase, audioBlob }: FeedbackDisplayProps) {
  const [showCaseScript, setShowCaseScript] = useState(false);
  const [showAudioPlayer, setShowAudioPlayer] = useState(false);
  const [showRubric, setShowRubric] = useState(false);
  const [activeSection, setActiveSection] = useState<'frame' | 'subjective' | 'objective' | 'assessment' | 'plan'>('frame');
  const [showInaccuracies, setShowInaccuracies] = useState<{[key: string]: boolean}>({
    frame: false,
    subjective: false,
    objective: false,
    assessment: false,
    plan: false
  });
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const feedbackScrollRef = useRef<HTMLDivElement>(null);
  const audioRef = useRef<HTMLAudioElement>(null);

  // Create audio URL from blob
  useEffect(() => {
    if (audioBlob) {
      const url = URL.createObjectURL(audioBlob);
      setAudioUrl(url);
      return () => {
        URL.revokeObjectURL(url);
      };
    }
  }, [audioBlob]);

  // Scroll to top and reset inaccuracies view when section changes
  useEffect(() => {
    if (feedbackScrollRef.current) {
      feedbackScrollRef.current.scrollTop = 0;
    }
    // Reset inaccuracies view when switching sections
    setShowInaccuracies(prev => ({...prev, [activeSection]: false}));
  }, [activeSection]);

  const getGradeColor = (grade: number) => {
    if (grade >= 9) return 'text-green-400';
    if (grade >= 7) return 'text-copper';
    if (grade >= 5) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getGradeBorderColor = (grade: number) => {
    if (grade >= 9) return 'border-green-500';
    if (grade >= 7) return 'border-copper';
    if (grade >= 5) return 'border-yellow-500';
    return 'border-red-500';
  };

  const getSectionScore = (sectionKey: 'frame' | 'subjective' | 'objective' | 'assessment' | 'plan') => {
    const section = feedback.soapSections[sectionKey];
    return { score: section.score, maxScore: section.maxScore };
  };

  const getSectionColor = (score: number, maxScore: number) => {
    const percentage = (score / maxScore) * 100;
    if (percentage >= 85) return 'text-green-400';
    if (percentage >= 70) return 'text-copper';
    if (percentage >= 50) return 'text-yellow-400';
    return 'text-red-400';
  };

  return (
    <div className="space-y-6">
      <div className={`glass rounded-3xl shadow-float p-4 sm:p-6 lg:p-8 border-l-4 ${getGradeBorderColor(feedback.metrics.overallGrade)}`}>
        <h2 className="text-xl sm:text-2xl font-light text-black mb-4 sm:mb-6 tracking-tight">Performance Summary</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 sm:gap-6">
          <div className="flex items-center gap-3 sm:gap-4">
            <div className="p-3 sm:p-4 rounded-2xl bg-dark-card">
              <Award className={`w-6 h-6 sm:w-8 sm:h-8 ${getGradeColor(feedback.metrics.overallGrade)}`} />
            </div>
            <div>
              <div className="text-xs sm:text-sm text-black/80 font-light">Overall Grade</div>
              <div className="text-2xl sm:text-3xl font-light tracking-tight text-black">
                {feedback.metrics.overallGrade}/10
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3 sm:gap-4">
            <div className="p-3 sm:p-4 rounded-2xl bg-dark-card">
              <Clock className="w-6 h-6 sm:w-8 sm:h-8 text-copper" />
            </div>
            <div>
              <div className="text-xs sm:text-sm text-black/80 font-light">Presentation Length</div>
              <div className="text-xl sm:text-2xl font-light text-black">
                {feedback.metrics.wordCount} words
              </div>
              <div className="text-xs sm:text-sm text-black font-light">
                ~{feedback.metrics.estimatedMinutes} min
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3 sm:gap-4">
            <div className="p-3 sm:p-4 rounded-2xl bg-dark-card">
              <Filter className={`w-6 h-6 sm:w-8 sm:h-8 ${
                feedback.metrics.fillerWordCount === 0 ? 'text-green-400' :
                feedback.metrics.fillerWordCount <= 5 ? 'text-yellow-400' :
                'text-red-400'
              }`} />
            </div>
            <div>
              <div className="text-xs sm:text-sm text-black/80 font-light">Filler Words</div>
              <div className="text-xl sm:text-2xl font-light text-black">
                {feedback.metrics.fillerWordCount}
              </div>
              {feedback.metrics.fillerWords.length > 0 && (
                <div className="text-xs text-black font-light mt-1">
                  Most common: {feedback.metrics.fillerWords[0].word} ({feedback.metrics.fillerWords[0].count}×)
                </div>
              )}
              {feedback.metrics.excessFillerWords && feedback.metrics.excessFillerWords.length > 0 && (
                <div className="text-xs text-red-600 font-light mt-1">
                  Consider using fewer filler words such as: {feedback.metrics.excessFillerWords.slice(0, 5).join(', ')}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>



      <div className="flex flex-col sm:flex-row gap-3">
        <button
          onClick={() => setShowCaseScript(!showCaseScript)}
          className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-full bg-[#0B2B26] hover:bg-[#0B2B26]/90 transition-smooth font-medium text-white text-sm border-none w-full sm:w-auto"
        >
          <FileText className="w-5 h-5" />
          <span className="whitespace-nowrap">Case Script</span>
        </button>

        {audioUrl && (
          <button
            onClick={() => setShowAudioPlayer(!showAudioPlayer)}
            className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-full bg-[#0B2B26] hover:bg-[#0B2B26]/90 transition-smooth font-medium text-white text-sm border-none w-full sm:w-auto"
          >
            <Volume2 className="w-5 h-5" />
            <span className="whitespace-nowrap">Playback</span>
          </button>
        )}

        <button
          onClick={() => setShowRubric(!showRubric)}
          className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-full bg-[#0B2B26] hover:bg-[#0B2B26]/90 transition-smooth font-medium text-white text-sm border-none w-full sm:w-auto"
        >
          <Award className="w-5 h-5" />
          <span className="whitespace-nowrap">Rubric</span>
        </button>
      </div>

      {showCaseScript && (
        <CaseDisplay medicalCase={medicalCase} />
      )}

      {showAudioPlayer && audioUrl && (
        <div className="glass rounded-3xl shadow-float p-4 sm:p-6">
          <h3 className="text-lg sm:text-xl font-light text-black mb-4 tracking-tight">Audio Playback</h3>
          <div className="bg-[#DAF1DE] rounded-2xl p-4 sm:p-5 border border-[#0B2B26]">
            <audio ref={audioRef} src={audioUrl} controls className="w-full" />
          </div>
        </div>
      )}

      {showRubric && (
        <div className="glass rounded-3xl shadow-float p-4 sm:p-6">
          <h3 className="text-lg sm:text-xl font-light text-black mb-4 tracking-tight">Grading Rubric</h3>
          <div className="bg-[#DAF1DE] rounded-2xl p-4 sm:p-5 border border-[#0B2B26] space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-white/50 rounded-xl p-4">
                <h4 className="font-medium text-black mb-2 text-sm">Frame & Context (Steps 1-6)</h4>
                <p className="text-xs text-black/80 mb-2">Max Points: {feedback.soapSections.frame.maxScore}</p>
                <ul className="text-xs text-black/70 space-y-1 list-disc list-inside">
                  <li>Greeting & Introduction</li>
                  <li>HIPAA & Consent</li>
                  <li>Context Statement</li>
                  <li>Delivery & Pacing</li>
                </ul>
              </div>

              <div className="bg-white/50 rounded-xl p-4">
                <h4 className="font-medium text-black mb-2 text-sm">Subjective (Steps 7-12)</h4>
                <p className="text-xs text-black/80 mb-2">Max Points: {feedback.soapSections.subjective.maxScore}</p>
                <ul className="text-xs text-black/70 space-y-1 list-disc list-inside">
                  <li>Chief Complaint & HPI</li>
                  <li>Pertinent Findings</li>
                  <li>Background & Medical History</li>
                  <li>Family History</li>
                </ul>
              </div>

              <div className="bg-white/50 rounded-xl p-4">
                <h4 className="font-medium text-black mb-2 text-sm">Objective (Step 13)</h4>
                <p className="text-xs text-black/80 mb-2">Max Points: {feedback.soapSections.objective.maxScore}</p>
                <ul className="text-xs text-black/70 space-y-1 list-disc list-inside">
                  <li>Signposting & Vitals</li>
                  <li>Physical Examination</li>
                  <li>Lab & Imaging Results</li>
                  <li>EMR Accuracy Check</li>
                </ul>
              </div>

              <div className="bg-white/50 rounded-xl p-4">
                <h4 className="font-medium text-black mb-2 text-sm">Assessment (Step 14)</h4>
                <p className="text-xs text-black/80 mb-2">Max Points: {feedback.soapSections.assessment.maxScore}</p>
                <ul className="text-xs text-black/70 space-y-1 list-disc list-inside">
                  <li>Working Diagnosis</li>
                  <li>Differential Diagnosis</li>
                  <li>Clinical Reasoning</li>
                  <li>Pertinent Positives/Negatives</li>
                </ul>
              </div>

              <div className="bg-white/50 rounded-xl p-4">
                <h4 className="font-medium text-black mb-2 text-sm">Plan (Steps 15-19)</h4>
                <p className="text-xs text-black/80 mb-2">Max Points: {feedback.soapSections.plan.maxScore}</p>
                <ul className="text-xs text-black/70 space-y-1 list-disc list-inside">
                  <li>Symptomatic Relief</li>
                  <li>Investigations</li>
                  <li>Interventions & Treatments</li>
                  <li>Disposition & Education</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="glass rounded-3xl shadow-float p-4 sm:p-6">
        <h3 className="text-lg sm:text-xl font-light text-black mb-4 tracking-tight">Your Transcript</h3>

        {/* Transcript spans full width at top */}
        <div className="bg-[#DAF1DE] rounded-2xl p-3 sm:p-4 border border-[#0B2B26] max-h-[300px] sm:max-h-[350px] overflow-y-auto transcript-scroll mb-4">
          <div className="text-black text-xs sm:text-sm leading-relaxed font-light whitespace-pre-wrap">
            {transcript}
          </div>
        </div>

        {/* Section buttons in a row below transcript */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 mb-4">
          <button
            onClick={() => setActiveSection('frame')}
            className={`px-1 sm:px-2 py-3 rounded-xl transition-smooth font-medium text-xs sm:text-sm ${
              activeSection === 'frame'
                ? 'bg-[#0B2B26] text-white'
                : 'bg-[#DAF1DE] text-[#0B2B26] border-2 border-[#0B2B26] hover:bg-[#0B2B26] hover:text-white'
            }`}
          >
            Frame
          </button>

          <button
            onClick={() => setActiveSection('subjective')}
            className={`px-1 sm:px-2 py-3 rounded-xl transition-smooth font-medium text-xs sm:text-sm ${
              activeSection === 'subjective'
                ? 'bg-[#0B2B26] text-white'
                : 'bg-[#DAF1DE] text-[#0B2B26] border-2 border-[#0B2B26] hover:bg-[#0B2B26] hover:text-white'
            }`}
          >
            Subjective
          </button>

          <button
            onClick={() => setActiveSection('objective')}
            className={`px-1 sm:px-2 py-3 rounded-xl transition-smooth font-medium text-xs sm:text-sm ${
              activeSection === 'objective'
                ? 'bg-[#0B2B26] text-white'
                : 'bg-[#DAF1DE] text-[#0B2B26] border-2 border-[#0B2B26] hover:bg-[#0B2B26] hover:text-white'
            }`}
          >
            Objective
          </button>

          <button
            onClick={() => setActiveSection('assessment')}
            className={`px-1 sm:px-2 py-3 rounded-xl transition-smooth font-medium text-xs sm:text-sm ${
              activeSection === 'assessment'
                ? 'bg-[#0B2B26] text-white'
                : 'bg-[#DAF1DE] text-[#0B2B26] border-2 border-[#0B2B26] hover:bg-[#0B2B26] hover:text-white'
            }`}
          >
            Assessment
          </button>

          <button
            onClick={() => setActiveSection('plan')}
            className={`px-1 sm:px-2 py-3 rounded-xl transition-smooth font-medium text-xs sm:text-sm ${
              activeSection === 'plan'
                ? 'bg-[#0B2B26] text-white'
                : 'bg-[#DAF1DE] text-[#0B2B26] border-2 border-[#0B2B26] hover:bg-[#0B2B26] hover:text-white'
            }`}
          >
            Plan
          </button>
        </div>

        {/* Feedback box appears below when section is clicked */}
        <div className="bg-[#DAF1DE] rounded-2xl p-3 sm:p-4 space-y-2 border border-[#0B2B26]">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <h5 className="font-medium text-black text-xs sm:text-sm capitalize">
                {showInaccuracies[activeSection] ? `${activeSection} Inaccuracies` : `${activeSection} Feedback`}
              </h5>
              {(() => {
                let sectionInaccuracies: string[] = [];
                if (activeSection === 'frame') {
                  sectionInaccuracies = feedback.inaccuracies.frame;
                } else if (activeSection === 'subjective') {
                  sectionInaccuracies = feedback.inaccuracies.subjective;
                } else if (activeSection === 'objective') {
                  sectionInaccuracies = feedback.inaccuracies.objective;
                } else if (activeSection === 'assessment') {
                  sectionInaccuracies = feedback.inaccuracies.assessment;
                } else if (activeSection === 'plan') {
                  sectionInaccuracies = feedback.inaccuracies.plan;
                }

                return sectionInaccuracies.length > 0 ? (
                  <button
                    onClick={() => setShowInaccuracies(prev => ({...prev, [activeSection]: !prev[activeSection]}))}
                    className="hover:opacity-70 transition-smooth relative group"
                    aria-label="View inaccuracies"
                  >
                    <AlertCircle className="w-5 h-5 text-[#800020] fill-none" />
                    <span className="absolute left-1/2 -translate-x-1/2 top-full mt-2 px-3 py-1.5 bg-[#0B2B26] text-white text-xs rounded-lg whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10">
                      View inaccuracies
                    </span>
                  </button>
                ) : null;
              })()}
            </div>
            <span className="text-xs sm:text-sm font-medium text-black">
              {feedback.soapSections[activeSection].score}/{feedback.soapSections[activeSection].maxScore}
            </span>
          </div>

          {!showInaccuracies[activeSection] ? (
            // Show regular feedback
            feedback.soapSections[activeSection].feedback.length > 0 ? (
              <div ref={feedbackScrollRef} className="space-y-2 max-h-[300px] sm:max-h-[400px] overflow-y-auto transcript-scroll">
                {feedback.soapSections[activeSection].feedback.map((item, idx) => {
                  const isGood = item.startsWith('✓') || item.startsWith('✔');
                  const isWarning = item.startsWith('⚠');
                  const isMissing = item.startsWith('✗');
                  const isTip = item.startsWith('Tip:');

                  let colorClasses = '';
                  if (isGood) {
                    colorClasses = 'bg-white/50 border-[#0B2B26] text-black';
                  } else if (isWarning) {
                    colorClasses = 'bg-white/50 border-[#0B2B26] text-black';
                  } else if (isMissing) {
                    colorClasses = 'bg-white/50 border-[#0B2B26] text-black';
                  } else if (isTip) {
                    colorClasses = 'bg-white/50 border-[#0B2B26] text-black';
                  } else {
                    colorClasses = 'bg-white/50 border-[#0B2B26] text-black';
                  }

                  // Remove the symbol from the text since we'll display it as an icon
                  let displayText = item;
                  let icon = null;

                  if (isGood) {
                    displayText = item.replace(/^[✓✔]\s*/, '').trim();
                    icon = <CheckCircle className="w-4 h-4 text-black flex-shrink-0 fill-black" />;
                  } else if (isWarning) {
                    displayText = item.replace('⚠', '').trim();
                    icon = <AlertTriangle className="w-4 h-4 text-black flex-shrink-0 fill-none stroke-black stroke-2" />;
                  } else if (isMissing) {
                    displayText = item.replace('✗', '').trim();
                    icon = <AlertTriangle className="w-4 h-4 text-black flex-shrink-0 fill-none stroke-black stroke-2" />;
                  } else if (isTip) {
                    // Bold the "Tip:" part
                    displayText = item.replace(/^Tip:\s*/, '');
                  }

                  return (
                    <div key={idx} className={`p-2 sm:p-3 rounded-xl border ${colorClasses} text-xs font-light break-words flex items-start gap-2`}>
                      {icon}
                      <span className="flex-1">
                        {isTip ? <><span className="font-semibold">Tip:</span> {displayText}</> : displayText}
                      </span>
                    </div>
                  );
                })}
                {feedback.aiEnhancement?.sectionEnhancements?.[activeSection] && (
                  <div className="p-2 sm:p-3 rounded-xl border border-[#0B2B26] bg-white/50 text-xs font-light break-words">
                    <span className="font-semibold">Tip:</span> {feedback.aiEnhancement.sectionEnhancements[activeSection]}
                  </div>
                )}
              </div>
            ) : (
              <div className="text-black text-sm italic">
                No feedback for this section.
              </div>
            )
          ) : (
            // Show inaccuracies
            (() => {
              let sectionInaccuracies: string[] = [];
              if (activeSection === 'frame') {
                sectionInaccuracies = feedback.inaccuracies.frame;
              } else if (activeSection === 'subjective') {
                sectionInaccuracies = feedback.inaccuracies.subjective;
              } else if (activeSection === 'objective') {
                sectionInaccuracies = feedback.inaccuracies.objective;
              } else if (activeSection === 'assessment') {
                sectionInaccuracies = feedback.inaccuracies.assessment;
              } else if (activeSection === 'plan') {
                sectionInaccuracies = feedback.inaccuracies.plan;
              }

              return (
                <div className="space-y-3">
                  <p className="text-xs text-black/90 italic">Cross-check all details with the patient's EMR and case script before presenting.</p>
                  <div className="space-y-2 max-h-[300px] sm:max-h-[400px] overflow-y-auto transcript-scroll">
                    {sectionInaccuracies.map((issue, idx) => (
                      <div key={idx} className="p-2 sm:p-3 rounded-xl border border-[#0B2B26] bg-white/50 text-black text-xs font-light break-words">
                        • {issue}
                      </div>
                    ))}
                  </div>
                </div>
              );
            })()
          )}
        </div>
      </div>
    </div>
  );
}
